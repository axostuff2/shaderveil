// Screen-space GI using reconstructed positions and normals: lit neighbours bounce light onto
// surfaces that face them, falling off with distance.
uniform float intensity; // @param 0.8 0.0 3.0
uniform float radius;    // @param 90.0 10.0 250.0

float lum(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

float ign(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    float conf = clamp(sceneConf(vUV) * 2.0, 0.0, 1.0) * (1.0 - screenLocked(vUV));
    vec3 P = scenePos(vUV);
    vec3 n = sceneNormal(vUV);
    float rot = ign(gl_FragCoord.xy + float(uFrame % 8) * 5.588238) * 6.2831853;

    vec3 gi = vec3(0.0);
    const int N = 16;
    for (int i = 0; i < N; i++) {
        float fi = float(i) + 0.5;
        float r = fi / float(N);
        float a = fi * 2.39996323 + rot;
        vec2 uvs = vUV + vec2(cos(a), sin(a)) * r * r * radius * uTexel;
        vec3 v = scenePos(uvs) - P;
        float d = length(v) + 1e-3;
        float cosR = max(dot(n, v / d), 0.0);
        vec3 s = texture(uTex, uvs).rgb;
        gi += s * (0.25 + lum(s)) * cosR / (1.0 + d * d * 3.0) * (1.0 - r);
    }
    gi /= float(N);
    fragColor = vec4(c + gi * intensity * (c + 0.2) * conf, 1.0);
}

// Screen-space ambient occlusion from the reconstructed depth and normals.
uniform float strength; // @param 1.0 0.0 3.0
uniform float radius;   // @param 40.0 5.0 120.0
uniform float bias;     // @param 0.15 0.0 0.5

float ign(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    float conf = sceneConf(vUV);
    vec3 P = scenePos(vUV);
    vec3 n = sceneNormal(vUV);
    float rot = ign(gl_FragCoord.xy + float(uFrame % 8) * 5.588238) * 6.2831853;

    float occ = 0.0;
    const int N = 12;
    for (int i = 0; i < N; i++) {
        float fi = float(i) + 0.5;
        float r = sqrt(fi / float(N));
        float a = fi * 2.39996323 + rot;
        vec2 off = vec2(cos(a), sin(a)) * r * radius * uTexel;
        vec3 v = scenePos(vUV + off) - P;
        float d = length(v) + 1e-4;
        occ += max(dot(n, v / d) - bias, 0.0) / (1.0 + d * d * 4.0);
    }
    occ /= float(N);
    float ao = clamp(1.0 - occ * strength * 2.0, 0.0, 1.0);
    ao = mix(1.0, ao, clamp(conf * 2.0, 0.0, 1.0) * (1.0 - screenLocked(vUV)));
    fragColor = vec4(c * ao, 1.0);
}

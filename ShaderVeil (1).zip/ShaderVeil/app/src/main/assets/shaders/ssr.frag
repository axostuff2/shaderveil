// Approximate floor reflections (planar SSR). No depth is available from a screen capture, so
// this assumes a horizontal ground plane below `horizon`: for each ground pixel it marches UP the
// column to the first strong colour change (an object's base), then mirrors around that point.
// Fresnel grows toward the horizon, and `glossy` gates by local smoothness.
uniform float horizon;   // @param 0.55 0.2 0.9
uniform float strength;  // @param 0.5 0.0 1.0
uniform float maxDist;   // @param 0.35 0.05 0.6
uniform float roughness; // @param 6.0 0.0 20.0
uniform float glossy;    // @param 0.5 0.0 1.0

float lum(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

void main() {
    vec2 uv = vUV;
    vec3 c = texture(uTex, uv).rgb;

    float ground = smoothstep(horizon, horizon - 0.08, uv.y);
    if (ground <= 0.001) {
        fragColor = vec4(c, 1.0);
        return;
    }

    // find the base of whatever stands above this pixel
    float stepY = maxDist / 24.0;
    float yb = -1.0;
    for (int i = 1; i <= 24; i++) {
        float y = uv.y + float(i) * stepY;
        if (y >= 1.0) break;
        vec3 s = texture(uTex, vec2(uv.x, y)).rgb;
        if (length(s - c) > 0.22) {
            yb = y;
            break;
        }
    }
    if (yb < 0.0) {
        fragColor = vec4(c, 1.0);
        return;
    }

    float dist = yb - uv.y;
    float yr = 2.0 * yb - uv.y;
    if (yr <= 0.0 || yr >= 1.0 || dist > maxDist) {
        fragColor = vec4(c, 1.0);
        return;
    }

    // roughness blur grows with distance travelled
    float bl = roughness * (0.3 + dist / maxDist) * uTexel.x;
    vec3 r = texture(uTex, vec2(uv.x, yr)).rgb * 0.5
           + texture(uTex, vec2(uv.x - bl, yr)).rgb * 0.25
           + texture(uTex, vec2(uv.x + bl, yr)).rgb * 0.25;

    // smoothness gate from local variance
    vec3 n1 = texture(uTex, uv + vec2(uTexel.x * 3.0, 0.0)).rgb;
    vec3 n2 = texture(uTex, uv - vec2(uTexel.x * 3.0, 0.0)).rgb;
    vec3 n3 = texture(uTex, uv + vec2(0.0, uTexel.y * 3.0)).rgb;
    vec3 n4 = texture(uTex, uv - vec2(0.0, uTexel.y * 3.0)).rgb;
    float m = (lum(n1) + lum(n2) + lum(n3) + lum(n4)) * 0.25;
    float v = abs(lum(n1) - m) + abs(lum(n2) - m) + abs(lum(n3) - m) + abs(lum(n4) - m);
    float gloss = 1.0 - smoothstep(0.02, 0.12, v);

    float fres = pow(1.0 - clamp((horizon - uv.y) / horizon, 0.0, 1.0), 2.0);
    float fade = 1.0 - dist / maxDist;
    float amt = strength * fres * fade * ground * mix(1.0, gloss, glossy);

    fragColor = vec4(mix(c, r, clamp(amt, 0.0, 1.0)), 1.0);
}

// Screen-space motion blur driven by block-matched optical flow between the previous
// and current captured frames (uPrevSrc vs uOrig). Two-stage 3x3 search, 3-tap patches.
// Heavy: lower the render scale if it stutters. Put it FIRST in the chain.
uniform float shutter; // @param 3.0 0.0 8.0
uniform float maxBlur; // @param 24.0 4.0 64.0
uniform float coarse;  // @param 6.0 2.0 16.0

float lum(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

float cost(vec2 p, vec2 o1, vec2 o2, float c0, float c1, float c2) {
    return abs(lum(texture(uPrevSrc, p).rgb) - c0)
         + abs(lum(texture(uPrevSrc, p + o1).rgb) - c1)
         + abs(lum(texture(uPrevSrc, p + o2).rgb) - c2);
}

void main() {
    vec2 uv = vUV;
    vec2 o1 = vec2(2.0, 0.0) * uTexel;
    vec2 o2 = vec2(0.0, 2.0) * uTexel;
    float c0 = lum(texture(uOrig, uv).rgb);
    float c1 = lum(texture(uOrig, uv + o1).rgb);
    float c2 = lum(texture(uOrig, uv + o2).rgb);

    // coarse search
    vec2 best = vec2(0.0);
    float bestCost = 1e9;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 g = vec2(float(x), float(y));
            vec2 d = g * coarse * uTexel;
            float k = cost(uv + d, o1, o2, c0, c1, c2) + length(g) * 0.01; // bias toward no motion
            if (k < bestCost) { bestCost = k; best = d; }
        }
    }
    // refine around the coarse winner
    vec2 base = best;
    float step2 = coarse * 0.34;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 g = vec2(float(x), float(y));
            vec2 d = base + g * step2 * uTexel;
            float k = cost(uv + d, o1, o2, c0, c1, c2) + length(d / uTexel) * 0.0005;
            if (k < bestCost) { bestCost = k; best = d; }
        }
    }

    // content moved from (uv + best) in the previous frame to uv now
    vec2 v = -best * shutter;
    float conf = 1.0 - smoothstep(0.10, 0.35, bestCost);
    v *= conf;
    float len = length(v / uTexel);
    if (len > maxBlur) v *= maxBlur / len;

    vec3 acc = vec3(0.0);
    const int N = 12;
    for (int i = 0; i < N; i++) {
        float t = float(i) / float(N - 1) - 0.5;
        acc += texture(uTex, uv + v * t).rgb;
    }
    fragColor = vec4(acc / float(N), 1.0);
}

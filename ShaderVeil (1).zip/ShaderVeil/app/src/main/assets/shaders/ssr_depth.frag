// Screen-space reflections on upward-facing surfaces: marches a reflected ray through the
// reconstructed depth and samples the screen where it lands.
uniform float strength;  // @param 0.6 0.0 1.0
uniform float maxDist;   // @param 3.0 0.5 8.0
uniform float thickness; // @param 0.35 0.05 1.0
uniform float roughness; // @param 4.0 0.0 16.0
uniform float upThresh;  // @param 0.55 0.2 0.95

float ign(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    float conf = sceneConf(vUV);
    if (conf < 0.05) {
        fragColor = vec4(c, 1.0);
        return;
    }
    vec3 P = scenePos(vUV);
    vec3 n = sceneNormal(vUV);
    float floorness = smoothstep(upThresh - 0.1, upThresh + 0.1, n.y);
    if (floorness < 0.01) {
        fragColor = vec4(c, 1.0);
        return;
    }
    vec3 V = normalize(P);
    vec3 R = reflect(V, n);
    float aspect = uRes.x / uRes.y;

    float stepLen = maxDist / 24.0;
    float t = stepLen * (0.5 + ign(gl_FragCoord.xy));
    float hit = 0.0;
    vec2 hitUV = vec2(0.0);
    float hitT = 0.0;
    for (int i = 0; i < 24; i++) {
        vec3 Q = P + R * t;
        if (Q.z <= 0.05) break;
        vec2 uvQ = Q.xy / (Q.z * vec2(aspect, 1.0)) + 0.5;
        if (any(lessThan(uvQ, vec2(0.0))) || any(greaterThan(uvQ, vec2(1.0)))) break;
        float dz = Q.z - sceneZ(uvQ);
        if (dz > 0.0 && dz < thickness) {
            hit = 1.0;
            hitUV = uvQ;
            hitT = t;
            break;
        }
        t += stepLen;
    }

    if (hit < 0.5) {
        fragColor = vec4(c, 1.0);
        return;
    }
    vec2 b = vec2(roughness) * uTexel;
    vec3 refl = texture(uTex, hitUV).rgb * 0.5
              + texture(uTex, hitUV + vec2(b.x, 0.0)).rgb * 0.25
              + texture(uTex, hitUV - vec2(b.x, 0.0)).rgb * 0.25;
    float fres = pow(1.0 - max(dot(-V, n), 0.0), 3.0);
    float edge = smoothstep(0.0, 0.1, min(min(hitUV.x, hitUV.y), min(1.0 - hitUV.x, 1.0 - hitUV.y)));
    float amt = strength * floorness * fres * (1.0 - hitT / maxDist) * edge
              * clamp(conf * 2.0, 0.0, 1.0) * (1.0 - screenLocked(vUV));
    fragColor = vec4(mix(c, refl, clamp(amt, 0.0, 1.0)), 1.0);
}

// PHONE WALKER - a game inside your game (prototype). Needs ShaderVeil v0.3+. Put it FIRST / ALONE in the chain.
//
// You are a guy walking a city block in first person with his face in his phone. The phone screen shows your
// REAL captured game. His thumbs drift to wherever the picture is changing most (left half -> left thumb,
// right half -> right thumb), so they roughly follow what you do in the game.
// Random episodes (every `episode` seconds): 1 just walking, 2 BUMP (phone flies out of his hands, cracked
// screen), 3 CROSS the street (looks up, checks traffic, crosses), 4 RUN OVER (crosses head-down, car, flash,
// hospital bed, still holding the phone).
// forceEvent: 0 random, 1 walk, 2 bump, 3 cross, 4 run over (use it to preview). chaos raises the odds of 4.
//
// No ray marching: every object is a box or capsule with a closed-form ray hit (what a rasteriser would draw).
// @scale 0.5
uniform float episode;    // @param 24.0 20.0 60.0
uniform float chaos;      // @param 1.0 0.0 3.0
uniform float forceEvent; // @param 0.0 0.0 4.0
uniform float daylight;   // @param 0.35 0.0 1.0
uniform float phoneSize;  // @param 1.0 0.6 1.8
uniform float fov;        // @param 74.0 50.0 100.0

const float PI = 3.14159265;

float hash11(float p) { p = fract(p * 0.1031); p *= p + 33.33; p *= p + p; return fract(p); }
float hash12(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
mat3 rotX(float a) { float c = cos(a), s = sin(a); return mat3(1.0, 0.0, 0.0, 0.0, c, s, 0.0, -s, c); }
mat3 rotY(float a) { float c = cos(a), s = sin(a); return mat3(c, 0.0, -s, 0.0, 1.0, 0.0, s, 0.0, c); }
mat3 rotZ(float a) { float c = cos(a), s = sin(a); return mat3(c, s, 0.0, -s, c, 0.0, 0.0, 0.0, 1.0); }
mat3 eul(float y, float p, float r) { return rotY(y) * rotX(p) * rotZ(r); }

// ------------------------------------------------------------------ hit record
float gT; vec3 gN; vec3 gCol; float gEm; int gID; vec4 gAux;
// ids: 0 flat colour, 1 ground, 2 building, 3 phone screen, 4 hospital room, 5 monitor
void rec(float t, vec3 n, vec3 col, float em, int id) {
    if (t > 0.0 && t < gT) { gT = t; gN = n; gCol = col; gEm = em; gID = id; }
}

bool box(vec3 ro, vec3 rd, vec3 c, vec3 h, out float t, out vec3 n) {
    rd = mix(rd, vec3(1e-6), vec3(lessThan(abs(rd), vec3(1e-6))));
    vec3 m = 1.0 / rd; vec3 q = ro - c; vec3 k = abs(m) * h;
    vec3 t1 = -m * q - k; vec3 t2 = -m * q + k;
    float tN = max(max(t1.x, t1.y), t1.z); float tF = min(min(t2.x, t2.y), t2.z);
    t = tN; n = -sign(rd) * step(t1.yzx, t1.xyz) * step(t1.zxy, t1.xyz);
    return tN < tF && tF > 0.0 && tN > 0.0;
}
// cheap conservative hit test (distance of the entry point, or false)
bool boxAny(vec3 ro, vec3 rd, vec3 c, vec3 h, out float t) {
    rd = mix(rd, vec3(1e-6), vec3(lessThan(abs(rd), vec3(1e-6))));
    vec3 m = 1.0 / rd; vec3 q = ro - c; vec3 k = abs(m) * h;
    vec3 t1 = -m * q - k; vec3 t2 = -m * q + k;
    t = max(max(t1.x, t1.y), t1.z);
    return t < min(min(t2.x, t2.y), t2.z) && min(min(t2.x, t2.y), t2.z) > 0.0;
}
// inside of a box (room): far wall hit with inward normal
bool boxIn(vec3 ro, vec3 rd, vec3 c, vec3 h, out float t, out vec3 n) {
    rd = mix(rd, vec3(1e-6), vec3(lessThan(abs(rd), vec3(1e-6))));
    vec3 m = 1.0 / rd; vec3 q = ro - c; vec3 k = abs(m) * h;
    vec3 t2 = -m * q + k;
    t = min(min(t2.x, t2.y), t2.z);
    n = -sign(rd) * step(t2.xyz, t2.yzx) * step(t2.xyz, t2.zxy);
    return t > 0.0;
}
float capsule(vec3 ro, vec3 rd, vec3 pa, vec3 pb, float r, out vec3 n) {
    vec3 ba = pb - pa, oa = ro - pa;
    float baba = dot(ba, ba), bard = dot(ba, rd), baoa = dot(ba, oa), rdoa = dot(rd, oa), oaoa = dot(oa, oa);
    float a = baba - bard * bard;
    float b = baba * rdoa - baoa * bard;
    float c = baba * oaoa - baoa * baoa - r * r * baba;
    float h = b * b - a * c;
    if (h >= 0.0 && a > 1e-7) {
        float t = (-b - sqrt(h)) / a;
        float y = baoa + t * bard;
        if (y > 0.0 && y < baba) { n = (oa + t * rd - ba * y / baba) / r; return t; }
        vec3 oc = (y <= 0.0) ? oa : ro - pb;
        float b2 = dot(rd, oc), c2 = dot(oc, oc) - r * r, h2 = b2 * b2 - c2;
        if (h2 > 0.0) { t = -b2 - sqrt(h2); n = (oc + t * rd) / r; return t; }
    }
    return -1.0;
}
void cap(vec3 ro, vec3 rd, vec3 pa, vec3 pb, float r, vec3 col) {
    vec3 n; float t = capsule(ro, rd, pa, pb, r, n);
    if (t > 0.0) rec(t, n, col, 0.0, 0);
}
void bx(vec3 ro, vec3 rd, vec3 c, vec3 h, vec3 col, float em) {
    float t; vec3 n;
    if (box(ro, rd, c, h, t, n)) rec(t, n, col, em, 0);
}

// ------------------------------------------------------------------ event state (all functions of time)
int TYPE; float U; float EPI;
vec3 camPos; float camYaw; float camPd; float camRoll;
vec3 camRight; vec3 camUp; vec3 camFwd;
vec3 phPos; mat3 phM; float crack;
vec3 hdPos; mat3 hdM;
bool HOSP; float flashW; float fadeBlack; float signalGreen;
vec4 thumbs; vec2 tap;
const float ZX = 40.5;   // crosswalk
const vec3 HAND_OFF = vec3(0.0, -0.09, 0.30);

void poseWalk(float u, out vec3 pos, out float yaw, out float pd, out float roll) {
    pos = vec3(5.4 + 0.03 * sin(u * 2.8), 1.62 + 0.03 * abs(sin(u * 5.6)), 8.0 + 1.5 * u);
    yaw = 0.05 * sin(u * 0.4); pd = 0.85 + 0.05 * sin(u * 0.7); roll = 0.01 * sin(u * 2.8);
}

void poseBump(float u, out vec3 pos, out float yaw, out float pd, out float roll) {
    float ub = 9.0, tb = u - ub, z, walk = 1.0;
    if (u < ub) z = 8.0 + 1.5 * u;
    else if (u < ub + 5.4) { z = 21.5 - 0.45 * (1.0 - exp(-tb * 7.0)); walk = 0.0; }
    else z = 21.05 + 1.5 * (u - ub - 5.4);
    pd = 0.85; yaw = 0.0; roll = 0.0;
    if (tb > 0.0) {
        pd = mix(0.85, -0.2, smoothstep(0.0, 0.15, tb));
        pd = mix(pd, 0.98, smoothstep(1.3, 2.1, tb));
        pd = mix(pd, 0.85, smoothstep(4.3, 5.2, tb));
        yaw = 0.4 * smoothstep(0.0, 0.2, tb) * (1.0 - smoothstep(0.9, 1.7, tb));
        roll = 0.10 * sin(tb * 34.0) * exp(-tb * 7.0);
    }
    float crouch = smoothstep(1.8, 2.8, tb) * (1.0 - smoothstep(3.9, 4.9, tb));
    pos = vec3(5.4, 1.62 + walk * 0.03 * abs(sin(u * 5.6)) - 0.6 * crouch, z);
}

// crossing the road: run = true -> head down the whole way (accident)
const float U_HIT = 9.26;
void poseCross(float u, bool run, out vec3 pos, out float yaw, out float pd, out float roll) {
    float z = ZX - 1.5 * (7.0 - min(u, 7.0));
    float tS = run ? 7.7 : 9.4;
    float x = 5.4 - 1.6 * clamp(u - tS, 0.0, 6.75);
    yaw = -PI * 0.5 * smoothstep(6.8, 7.7, u);
    float headUp = 0.0;
    float walking = (u < 7.0 || (u > tS && u < tS + 6.75) || u > 17.3) ? 1.0 : 0.0;
    if (run) {
        pd = 0.85 - 0.8 * smoothstep(8.65, 9.1, u);
        yaw += 0.8 * smoothstep(8.65, 9.1, u);
    } else {
        headUp = smoothstep(7.2, 8.0, u) * (1.0 - smoothstep(16.3, 17.1, u));
        pd = mix(0.85, 0.05, headUp);
        float scan = smoothstep(8.0, 8.4, u) * (1.0 - smoothstep(8.5, 8.9, u)) * 0.9
                   - smoothstep(8.9, 9.2, u) * (1.0 - smoothstep(9.2, 9.5, u)) * 0.9;
        yaw += scan;
        yaw += PI * 0.5 * smoothstep(16.4, 17.6, u);
        if (u > 17.3) { z += 1.5 * (u - 17.3); }
    }
    pos = vec3(x, 1.62 + walking * 0.03 * abs(sin(u * 5.6)), z);
    roll = 0.01 * sin(u * 2.8);
}

void heldPose(vec3 pos, float yaw, float pd, float roll, out vec3 hp, out mat3 hm) {
    mat3 M = eul(yaw, pd, roll);
    hp = pos + M * HAND_OFF;
    hm = eul(yaw, pd + atan(-HAND_OFF.y, HAND_OFF.z), roll);
}

// ------------------------------------------------------------------ setup the whole episode for this frame
void setup() {
    float T = episode;
    EPI = floor(uTime / T);
    U = uTime - EPI * T;
    float r = hash11(EPI * 3.17 + 0.5);
    float pRun = 0.07 * chaos;
    TYPE = (EPI < 0.5) ? 0 : (r < pRun ? 3 : (r < pRun + 0.32 ? 1 : (r < pRun + 0.65 ? 2 : 0)));
    if (forceEvent > 0.5) TYPE = int(forceEvent + 0.5) - 1;

    HOSP = false; flashW = 0.0; fadeBlack = 0.0; signalGreen = 0.0; crack = 0.0;
    float yaw, pd, roll; vec3 pos;
    if (TYPE == 0) poseWalk(U, pos, yaw, pd, roll);
    else if (TYPE == 1) poseBump(U, pos, yaw, pd, roll);
    else poseCross(U, TYPE == 3, pos, yaw, pd, roll);

    if (TYPE == 2) signalGreen = step(9.2, U) * (1.0 - step(16.5, U));

    if (TYPE == 3) {
        float ti = U - U_HIT;
        if (ti > 0.0) {
            // flung by the car: along the car's direction, up and tumbling
            vec3 p0; float y0, pd0, r0;
            poseCross(U_HIT, true, p0, y0, pd0, r0);
            float g = 4.9;
            pos = p0;
            pos.z += -8.5 * (1.0 - exp(-1.4 * ti)) / 1.4;
            pos.x += -1.5 * (1.0 - exp(-1.4 * ti)) / 1.4;
            pos.y = max(0.3, p0.y + 4.0 * ti - g * ti * ti);
            yaw = y0 + 5.0 * (1.0 - exp(-1.5 * ti));
            pd = pd0 + 6.0 * (1.0 - exp(-2.0 * ti));
            roll = 1.4 * (1.0 - exp(-2.0 * ti));
            flashW = exp(-ti * 7.0);
            fadeBlack = smoothstep(U_HIT + 1.1, U_HIT + 1.8, U);
        }
        if (U > U_HIT + 2.3) {
            HOSP = true;
            fadeBlack = 1.0 - smoothstep(U_HIT + 2.3, U_HIT + 4.0, U);
            float th = U - (U_HIT + 2.3);
            pos = vec3(0.0, 0.98 + 0.01 * sin(th * 1.3), -1.75);
            yaw = 0.06 * sin(th * 0.5);
            pd = -1.2 + 0.7 * smoothstep(1.0, 9.0, th);
            roll = 0.0;
        }
    }
    camPos = pos; camYaw = yaw; camPd = pd; camRoll = roll;

    heldPose(pos, yaw, pd, roll, hdPos, hdM);
    phPos = hdPos; phM = hdM;

    if (TYPE == 1 && U > 9.0) {
        float ub = 9.0, tau = U - ub;
        vec3 bp; float by, bpd, br;
        poseBump(ub, bp, by, bpd, br);
        vec3 p0; mat3 m0;
        heldPose(bp, by, bpd, br, p0, m0);
        float pitch0 = bpd + atan(-HAND_OFF.y, HAND_OFF.z);
        vec3 v0 = vec3(0.3, 1.0, 0.9);
        float yRest = 0.006;
        float tf1 = (v0.y + sqrt(v0.y * v0.y + 19.6 * (p0.y - yRest))) / 9.8;
        float vy1 = 0.38 * (9.8 * tf1 - v0.y);
        float tf2 = 2.0 * vy1 / 9.8;
        float tr = tf1 + tf2;
        float s1 = min(tau, tf1), s2 = clamp(tau - tf1, 0.0, tf2);
        vec3 pp;
        pp.xz = p0.xz + v0.xz * s1 + v0.xz * 0.45 * s2 + v0.xz * 0.06 * (1.0 - exp(-max(tau - tr, 0.0) * 4.0));
        pp.y = tau < tf1 ? p0.y + v0.y * tau - 4.9 * tau * tau
             : (tau < tr ? yRest + vy1 * s2 - 4.9 * s2 * s2 : yRest);
        float sp = smoothstep(0.0, tr, tau);
        float pitchF = tau < tr ? mix(pitch0, PI * 0.5 + 4.0 * PI, sp) : PI * 0.5;
        float yawF = by + 0.7 * sp;
        float rollF = 0.6 * sin(tau * 11.0) * exp(-tau * 1.8);
        // pick up again
        float s = smoothstep(0.0, 1.0, U - (ub + 3.7));
        vec3 heldNow = hdPos;
        phPos = mix(pp, heldNow, s) + vec3(0.0, 0.25 * sin(PI * s), 0.0);
        float pitchHeld = camPd + atan(-HAND_OFF.y, HAND_OFF.z);
        phM = eul(mix(yawF, camYaw, s), mix(pitchF, pitchHeld, s), mix(rollF, camRoll, s));
        crack = step(tf1, tau);
    }
}

// ------------------------------------------------------------------ world
vec3 groundCol(vec3 p) {
    float zc = abs(p.z - 48.0 * floor(p.z / 48.0 + 0.5));
    bool crossRoad = zc < 6.5;
    float ax = abs(p.x);
    vec3 col;
    if (crossRoad || ax < 4.0) {
        col = vec3(0.07, 0.07, 0.075) * (0.8 + 0.4 * hash12(floor(p.xz * 5.0)));
        if (!crossRoad && ax < 0.12 && fract(p.z * 0.2) < 0.6) col = vec3(0.65, 0.5, 0.08);
        float zr = p.z - (48.0 * floor(p.z / 48.0) + ZX);
        if (abs(zr) < 1.2 && ax < 4.0 && fract(p.x * 1.1) < 0.55) col = vec3(0.75);
    } else {
        vec2 g = abs(fract(p.xz * 0.5) - 0.5) * 2.0;
        float grout = smoothstep(0.93, 0.98, max(g.x, g.y));
        col = vec3(0.42, 0.41, 0.40) * (0.85 + 0.2 * hash12(floor(p.xz * 0.5)));
        col = mix(col, col * 0.55, grout);
        if (ax < 4.25) col *= 0.7;
    }
    return col;
}

vec3 facade(vec3 p, vec3 n, vec4 aux) {
    float k = aux.x, side = aux.y;
    vec3 wall = mix(vec3(0.52, 0.47, 0.42), vec3(0.38, 0.42, 0.50), hash12(vec2(k, side) + 9.0));
    wall = mix(wall, vec3(0.6, 0.35, 0.3), step(0.8, hash12(vec2(k, side) + 4.0)) * 0.7);
    gEm = 0.0;
    if (n.y > 0.5) return wall * 0.7;
    vec2 q = abs(n.x) > 0.5 ? vec2(p.z, p.y) : vec2(p.x, p.y);
    if (q.y < 4.0) {
        // shop front: sign band + dark glass with a warm glow
        if (q.y > 3.0 && q.y < 3.8) {
            float hue = hash12(vec2(floor(q.x / 5.0), k) + side);
            gEm = 0.9;
            return 0.8 * (0.5 + 0.5 * cos(6.2831 * (hue + vec3(0.0, 0.33, 0.67))));
        }
        gEm = 0.35;
        return mix(vec3(0.1, 0.09, 0.08), vec3(0.9, 0.7, 0.4), step(0.5, hash12(floor(vec2(q.x / 3.0, k)))));
    }
    vec2 sz = vec2(2.4, 3.2);
    vec2 cell = floor(q / sz), f = fract(q / sz);
    if (f.x > 0.2 && f.x < 0.8 && f.y > 0.25 && f.y < 0.8) {
        float lit = hash12(cell + vec2(k, side) * 7.0);
        float prob = mix(0.75, 0.12, daylight);
        if (lit < prob) { gEm = 1.0; return vec3(1.0, 0.78, 0.45) * (0.8 + 0.6 * hash12(cell + 3.3)); }
        return vec3(0.07, 0.10, 0.15) + 0.2 * daylight * vec3(0.3, 0.5, 0.7);
    }
    return wall;
}

void traceBuildings(vec3 ro, vec3 rd) {
    int kc = int(floor(ro.z / 12.0 + 0.5));
    for (int s = 0; s < 2; s++) {
        float side = s == 0 ? 1.0 : -1.0;
        for (int kk = -1; kk <= 5; kk++) {
            int k = kc + kk;
            int km = ((k % 4) + 4) % 4;
            if (km == 0) continue;
            float tc; vec3 nc;
            if (!boxAny(ro, rd, vec3(side * 12.5, 16.5, 12.0 * float(k)), vec3(5.5, 16.5, 5.0), tc)) continue;
            if (tc > gT) continue;
            float h1 = hash12(vec2(float(k), side * 3.0 + 1.3));
            float depth = 6.0 + 5.0 * hash12(vec2(float(k) * 1.7, side));
            float hgt = 9.0 + 24.0 * h1 * h1;
            vec3 c = vec3(side * (7.0 + depth * 0.5), hgt * 0.5, 12.0 * float(k));
            float t; vec3 n;
            if (box(ro, rd, c, vec3(depth * 0.5, hgt * 0.5, 5.0), t, n) && t < gT) {
                gT = t; gN = n; gID = 2; gAux = vec4(float(k), side, h1, depth); gCol = vec3(0.0); gEm = 0.0;
            }
        }
    }
}

void traceLamps(vec3 ro, vec3 rd) {
    int kc = int(floor(ro.z / 12.0));
    for (int s = 0; s < 2; s++) {
        float side = s == 0 ? 1.0 : -1.0;
        for (int kk = 0; kk <= 3; kk++) {
            float z = 12.0 * float(kc + kk) + 6.0;
            float zc = abs(z - 48.0 * floor(z / 48.0 + 0.5));
            if (zc < 7.0) continue;
            float x = side * 4.6;
            vec3 oc = ro - vec3(x, 2.6, z);
            float b = dot(oc, rd), c = dot(oc, oc) - 3.2 * 3.2;
            if (b * b - c < 0.0) continue;
            cap(ro, rd, vec3(x, 0.0, z), vec3(x, 5.0, z), 0.07, vec3(0.1));
            cap(ro, rd, vec3(x, 5.0, z), vec3(x - side * 0.9, 5.1, z), 0.05, vec3(0.1));
            bx(ro, rd, vec3(x - side * 0.9, 5.0, z), vec3(0.25, 0.04, 0.12), vec3(1.0, 0.85, 0.55), 1.0);
        }
    }
}

void tracePed(vec3 ro, vec3 rd, vec3 bp, float ang, float ph, float seed, float walkAmt, float raise) {
    vec3 oc = ro - (bp + vec3(0.0, 0.9, 0.0));
    float b = dot(oc, rd), c = dot(oc, oc) - 1.2 * 1.2;
    if (b * b - c < 0.0 || (b > 0.0 && c > 0.0)) return;
    mat3 M = rotY(ang); mat3 Mi = transpose(M);
    vec3 o = Mi * (ro - bp), d = Mi * rd;
    vec3 shirt = 0.25 + 0.6 * vec3(hash11(seed), hash11(seed + 1.3), hash11(seed + 2.7));
    vec3 pants = vec3(0.08, 0.1, 0.18) * (0.6 + hash11(seed + 5.0));
    vec3 skin = vec3(0.85, 0.62, 0.5) * (0.55 + 0.45 * hash11(seed + 9.1));
    float sw = sin(ph) * 0.35 * walkAmt;
    vec3 n; float t;
    t = capsule(o, d, vec3(-0.09, 0.92, 0.0), vec3(-0.09, 0.06, sw), 0.075, n); if (t > 0.0) rec(t, M * n, pants, 0.0, 0);
    t = capsule(o, d, vec3(0.09, 0.92, 0.0), vec3(0.09, 0.06, -sw), 0.075, n); if (t > 0.0) rec(t, M * n, pants, 0.0, 0);
    t = capsule(o, d, vec3(0.0, 0.98, 0.0), vec3(0.0, 1.42, 0.0), 0.17, n); if (t > 0.0) rec(t, M * n, shirt, 0.0, 0);
    vec3 la = mix(vec3(-0.22, 0.85, -sw * 0.8), vec3(-0.3, 1.9, 0.1), raise);
    vec3 ra = mix(vec3(0.22, 0.85, sw * 0.8), vec3(0.3, 1.9, 0.1), raise);
    t = capsule(o, d, vec3(-0.21, 1.38, 0.0), la, 0.05, n); if (t > 0.0) rec(t, M * n, shirt * 0.9, 0.0, 0);
    t = capsule(o, d, vec3(0.21, 1.38, 0.0), ra, 0.05, n); if (t > 0.0) rec(t, M * n, shirt * 0.9, 0.0, 0);
    t = capsule(o, d, vec3(0.0, 1.6, 0.0), vec3(0.0, 1.65, 0.0), 0.11, n); if (t > 0.0) rec(t, M * n, skin, 0.0, 0);
}

bool pedState(int i, out vec3 bp, out float ang, out float ph, out float walkAmt, out float raise, out float seed) {
    bp = vec3(0.0); ang = 0.0; ph = 0.0; walkAmt = 1.0; raise = 0.0; seed = EPI * 11.0 + float(i) * 3.7;
    if (TYPE <= 1) {
        if (i == 0) {
            if (TYPE == 1) {
                float ub = 9.0, tb = U - ub;
                float x = 5.45 - 0.9 * smoothstep(0.1, 0.9, tb);
                float z = U < ub ? 22.12 + 1.5 * (ub - U) : 22.12 - 0.3 * (1.0 - exp(-tb * 8.0)) - 1.5 * max(tb - 1.5, 0.0);
                bp = vec3(x, 0.0, z); ang = PI;
                walkAmt = U < ub ? 1.0 : smoothstep(1.4, 1.8, tb);
                raise = (tb > 0.0) ? smoothstep(0.0, 0.3, tb) * (1.0 - smoothstep(1.2, 1.6, tb)) : 0.0;
                ph = U * 11.0;
                return true;
            }
            bp = vec3(-5.5, 0.0, 18.0 + 1.3 * U); ang = 0.0; ph = U * 10.0; return true;
        }
        if (i == 1) { bp = vec3(6.3, 0.0, 14.0 + 1.1 * U); ang = 0.0; ph = U * 9.0; return true; }
        bp = vec3(-5.2, 0.0, 40.0 - 1.2 * U); ang = PI; ph = U * 9.5; return true;
    }
    if (i == 0) { bp = vec3(-5.5, 0.0, ZX + 14.0 - 1.3 * U); ang = PI; ph = U * 10.0; return true; }
    if (i == 1) {
        float go = (TYPE == 2) ? clamp(U - 9.4, 0.0, 6.75) : 0.0;
        bp = vec3(6.3 - 1.6 * go, 0.0, ZX + 0.9);
        ang = (go > 0.0) ? -PI * 0.5 : -PI * 0.5 + 0.2;
        walkAmt = go > 0.0 && go < 6.7 ? 1.0 : 0.0; ph = U * 10.0; return true;
    }
    return false;
}

void traceCars(vec3 ro, vec3 rd) {
    for (int i = 0; i < 3; i++) {
        float x, z, dir = -1.0, spd = 10.0;
        bool on = true;
        if (TYPE <= 1) {
            dir = (i % 2 == 0) ? -1.0 : 1.0;
            x = dir < 0.0 ? 1.8 : -1.8;
            spd = 8.0 + float(i);
            z = mod(30.0 + 55.0 * float(i) + dir * spd * U, 160.0) - 20.0;
        } else if (TYPE == 2) {
            if (i == 0) { dir = -1.0; x = 1.8; spd = 11.0; z = ZX + dir * spd * (U - 8.6); }
            else if (i == 1) { dir = 1.0; x = -1.8; spd = 9.0; z = ZX + dir * spd * (U - 6.9); }
            else { dir = -1.0; x = 1.8; spd = 11.0; z = ZX + dir * spd * (U - 10.2); }
        } else {
            if (i == 0) {
                dir = -1.0; x = 1.8; spd = 13.0;
                float ti = U - U_HIT;
                z = ti < 0.0 ? ZX + 13.0 * (-ti) + 2.2 : ZX - 13.0 * (1.0 - exp(-1.2 * ti)) / 1.2 + 2.2;
            } else if (i == 1) { dir = 1.0; x = -1.8; spd = 9.0; z = ZX + dir * spd * (U - 4.5); }
            else on = false;
        }
        if (!on) continue;
        vec3 oc = ro - vec3(x, 0.8, z);
        float b = dot(oc, rd), c = dot(oc, oc) - 3.3 * 3.3;
        if (b * b - c < 0.0) continue;
        float sd = EPI * 5.0 + float(i) * 13.0 + 1.0;
        vec3 body = 0.15 + 0.7 * vec3(hash11(sd), hash11(sd + 1.0), hash11(sd + 2.0));
        if (TYPE == 3 && i == 0) body = vec3(0.75, 0.1, 0.08);
        bx(ro, rd, vec3(x, 0.55, z), vec3(0.9, 0.3, 2.2), body, 0.0);
        bx(ro, rd, vec3(x, 1.03, z - dir * 0.2), vec3(0.8, 0.27, 1.1), body * 0.8, 0.0);
        bx(ro, rd, vec3(x, 0.2, z), vec3(0.95, 0.2, 1.8), vec3(0.03), 0.0);
        bx(ro, rd, vec3(x - 0.55, 0.6, z + dir * 2.21), vec3(0.2, 0.1, 0.02), vec3(1.0, 0.95, 0.75), 1.0);
        bx(ro, rd, vec3(x + 0.55, 0.6, z + dir * 2.21), vec3(0.2, 0.1, 0.02), vec3(1.0, 0.95, 0.75), 1.0);
        bx(ro, rd, vec3(x - 0.55, 0.6, z - dir * 2.21), vec3(0.2, 0.08, 0.02), vec3(1.0, 0.1, 0.05), 0.8);
        bx(ro, rd, vec3(x + 0.55, 0.6, z - dir * 2.21), vec3(0.2, 0.08, 0.02), vec3(1.0, 0.1, 0.05), 0.8);
    }
}

void traceStreet(vec3 ro, vec3 rd) {
    if (rd.y < 0.0) {
        float t = -ro.y / rd.y;
        rec(t, vec3(0.0, 1.0, 0.0), vec3(0.0), 0.0, 1);
    }
    traceBuildings(ro, rd);
    traceLamps(ro, rd);
    // pedestrian signal across the road
    cap(ro, rd, vec3(-4.6, 0.0, ZX), vec3(-4.6, 2.5, ZX), 0.05, vec3(0.12));
    bx(ro, rd, vec3(-4.6, 2.8, ZX), vec3(0.1, 0.3, 0.25), mix(vec3(1.0, 0.1, 0.05), vec3(0.2, 1.0, 0.3), signalGreen), 1.0);
    for (int i = 0; i < 3; i++) {
        vec3 bp; float ang, ph, wa, rs, sd;
        if (pedState(i, bp, ang, ph, wa, rs, sd)) tracePed(ro, rd, bp, ang, ph, sd, wa, rs);
    }
    traceCars(ro, rd);
}

// ------------------------------------------------------------------ hospital
void traceHospital(vec3 ro, vec3 rd) {
    float t; vec3 n;
    if (boxIn(ro, rd, vec3(0.0, 1.5, 0.2), vec3(3.0, 1.5, 3.0), t, n)) rec(t, n, vec3(0.0), 0.0, 4);
    bx(ro, rd, vec3(0.0, 0.45, -0.2), vec3(0.55, 0.14, 1.9), vec3(0.75, 0.78, 0.82), 0.0);          // mattress
    bx(ro, rd, vec3(0.0, 0.7, -1.95), vec3(0.4, 0.09, 0.3), vec3(0.9), 0.0);                       // pillow
    bx(ro, rd, vec3(0.0, 0.66, 0.85), vec3(0.5, 0.1, 0.95), vec3(0.45, 0.62, 0.78), 0.0);          // blanket
    cap(ro, rd, vec3(-0.62, 0.95, -1.4), vec3(-0.62, 0.95, 1.7), 0.02, vec3(0.7));                  // rails
    cap(ro, rd, vec3(0.62, 0.95, -1.4), vec3(0.62, 0.95, 1.7), 0.02, vec3(0.7));
    cap(ro, rd, vec3(-0.62, 0.3, 0.0), vec3(-0.62, 0.95, 0.0), 0.02, vec3(0.7));
    cap(ro, rd, vec3(0.62, 0.3, 0.0), vec3(0.62, 0.95, 0.0), 0.02, vec3(0.7));
    cap(ro, rd, vec3(0.95, 0.0, -0.9), vec3(0.95, 2.1, -0.9), 0.025, vec3(0.7));                    // IV pole
    bx(ro, rd, vec3(0.95, 1.85, -0.9), vec3(0.07, 0.12, 0.04), vec3(0.95, 0.95, 0.7), 0.6);
    cap(ro, rd, vec3(0.95, 1.7, -0.9), vec3(0.3, 0.85, -1.05), 0.008, vec3(0.9));
    cap(ro, rd, vec3(-1.25, 0.0, 0.3), vec3(-1.25, 1.25, 0.3), 0.03, vec3(0.2));                    // monitor
    float tm; vec3 nm;
    if (box(ro, rd, vec3(-1.25, 1.45, 0.3), vec3(0.05, 0.2, 0.28), tm, nm)) rec(tm, nm, vec3(0.05), 0.0, nm.x > 0.5 ? 5 : 0);
}

vec3 roomCol(vec3 p, vec3 n) {
    gEm = 0.0;
    if (n.y < -0.5) {
        for (int i = 0; i < 4; i++) {
            vec2 c = vec2(i % 2 == 0 ? -1.0 : 1.0, i < 2 ? -1.0 : 1.2);
            if (abs(p.x - c.x) < 0.45 && abs(p.z - c.y) < 0.3) { gEm = 1.0; return vec3(1.0, 0.98, 0.92); }
        }
        return vec3(0.8);
    }
    if (n.y > 0.5) return vec3(0.6, 0.65, 0.62) * (0.8 + 0.2 * step(0.0, sin(p.x * 6.0) * sin(p.z * 6.0)));
    if (n.x < -0.5 && abs(p.z - 0.6) < 1.3 && abs(p.y - 1.7) < 0.9) { gEm = 1.0; return vec3(0.65, 0.8, 1.0) * (0.6 + 0.4 * daylight); }
    if (n.z < -0.5 && abs(p.x - 1.2) < 0.5 && p.y < 2.1) return vec3(0.35, 0.22, 0.12);
    return p.y < 1.0 ? vec3(0.35, 0.5, 0.45) : vec3(0.82, 0.88, 0.85);
}

vec3 ecg(vec3 p) {
    vec2 q = vec2(p.z - 0.3, p.y - 1.45) / vec2(0.56, 0.4) * 2.0;
    float x = q.x * 2.0 + U * 1.5;
    float ph = fract(x);
    float y = 0.55 * exp(-pow((ph - 0.5) * 18.0, 2.0)) - 0.18 * exp(-pow((ph - 0.42) * 25.0, 2.0)) + 0.07 * exp(-pow((ph - 0.7) * 10.0, 2.0));
    float l = exp(-abs(q.y * 0.8 - y) * 55.0);
    return vec3(0.1, 1.0, 0.35) * l + vec3(0.0, 0.05, 0.02);
}

// ------------------------------------------------------------------ phone + hands
vec3 crackOverlay(vec2 uv) {
    vec2 p = uv * vec2(5.0, 2.8);
    vec2 ip = floor(p), fp = fract(p);
    float d1 = 8.0, d2 = 8.0;
    for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
        vec2 g = vec2(float(i), float(j));
        vec2 o = vec2(hash12(ip + g), hash12(ip + g + 17.0));
        float d = length(g + o - fp);
        if (d < d1) { d2 = d1; d1 = d; } else if (d < d2) d2 = d;
    }
    float edge = d2 - d1;
    float near = 1.0 - smoothstep(0.25, 0.75, length(uv - vec2(0.3, 0.35)));
    return vec3(smoothstep(0.05, 0.0, edge) * near, near * 0.25, 0.0);
}

void tracePhoneAndHands(vec3 ro, vec3 rd) {
    float A = uRes.x / uRes.y;
    float hw = 0.155 * phoneSize, hh = hw / A;
    // phone
    mat3 Mi = transpose(phM);
    vec3 o = Mi * (ro - phPos), d = Mi * rd;
    float t; vec3 n;
    if (box(o, d, vec3(0.0), vec3(hw + 0.006, hh + 0.006, 0.004), t, n)) {
        vec3 hp = o + d * t;
        bool screen = n.z < -0.5 && abs(hp.x) < hw && abs(hp.y) < hh;
        if (screen) {
            vec2 uv = hp.xy / vec2(2.0 * hw, 2.0 * hh) + 0.5;
            if (t < gT) {
                gT = t; gN = phM * n; gID = 3; gAux = vec4(uv, 0.0, 0.0); gCol = vec3(0.0); gEm = 1.0;
            }
        } else {
            rec(t, phM * n, vec3(0.04), 0.0, 0);
        }
    }
    // hands attach to the CAMERA (hold pose), so they stay put when the phone is dropped
    if (dot(rd, camUp) > 0.1 || dot(rd, camFwd) < -0.1) return;
    mat3 Hi = hdM;
    vec3 skin = vec3(0.85, 0.62, 0.50);
    vec3 armR = HOSP ? vec3(0.92, 0.92, 0.88) : skin;
    vec3 palmL = hdPos + Hi * vec3(-hw - 0.012, -0.002, -0.014);
    vec3 palmR = hdPos + Hi * vec3(hw + 0.012, -0.002, -0.014);
    cap(ro, rd, palmL + Hi * vec3(0.0, hh * 0.9, 0.0), palmL - Hi * vec3(0.0, hh * 0.9, 0.0), 0.022, skin);
    cap(ro, rd, palmR + Hi * vec3(0.0, hh * 0.9, 0.0), palmR - Hi * vec3(0.0, hh * 0.9, 0.0), 0.022, armR);
    cap(ro, rd, palmL - Hi * vec3(0.0, hh * 0.9, 0.0), camPos + camRight * -0.22 + camUp * -0.55 + camFwd * 0.08, 0.04, skin);
    cap(ro, rd, palmR - Hi * vec3(0.0, hh * 0.9, 0.0), camPos + camRight * 0.22 + camUp * -0.55 + camFwd * 0.08, HOSP ? 0.055 : 0.04, armR);
    // thumbs follow the activity on the screen
    for (int s = 0; s < 2; s++) {
        vec2 tgt = s == 0 ? thumbs.xy : thumbs.zw;
        float tp = s == 0 ? tap.x : tap.y;
        vec3 base = (s == 0 ? palmL : palmR) + Hi * vec3(s == 0 ? 0.01 : -0.01, -hh * 0.45, -0.01);
        vec3 tip = hdPos + Hi * vec3((tgt.x - 0.5) * 2.0 * hw, (tgt.y - 0.5) * 2.0 * hh, -0.006 - 0.018 * (1.0 - tp));
        cap(ro, rd, base, tip, 0.0085, s == 0 ? skin : armR);
    }
}

// ------------------------------------------------------------------ shading
vec3 skyCol(vec3 rd) {
    float h = clamp(rd.y, 0.0, 1.0);
    vec3 horizon = mix(vec3(0.95, 0.5, 0.3), vec3(0.75, 0.82, 0.9), daylight);
    vec3 zenith = mix(vec3(0.06, 0.09, 0.2), vec3(0.25, 0.5, 0.9), daylight);
    vec3 c = mix(horizon, zenith, pow(h, 0.5));
    vec3 sun = normalize(vec3(-0.35, 0.18 + 0.4 * daylight, 0.85));
    c += vec3(1.0, 0.6, 0.3) * pow(max(dot(rd, sun), 0.0), 40.0) * 0.6;
    return c;
}

vec3 lightIt(vec3 p, vec3 n, vec3 alb, float em) {
    vec3 L = normalize(vec3(-0.5, 0.45, -0.7));
    vec3 sunC = mix(vec3(1.0, 0.5, 0.25), vec3(1.0, 0.95, 0.85), daylight) * (0.25 + 0.9 * daylight);
    vec3 amb = mix(vec3(0.08, 0.09, 0.15), vec3(0.45, 0.55, 0.7), daylight) * (0.7 + 0.5 * (n.y * 0.5 + 0.5));
    vec3 c = alb * (max(dot(n, L), 0.0) * sunC + amb);
    return mix(c, alb * 1.8, em);
}

void main() {
    histOut = vec4(0.0);
    ivec2 px = ivec2(gl_FragCoord.xy);

    // --- thumb targets: where is the picture changing? (state lives in two texels of the history texture)
    bool hasHist = textureSize(uHist, 0).x > 1;
    vec4 oldA = hasHist ? texelFetch(uHist, ivec2(0, 0), 0) : vec4(0.0);
    vec4 oldB = hasHist ? texelFetch(uHist, ivec2(1, 0), 0) : vec4(0.0);
    vec4 homeA = vec4(0.14, 0.24, 0.84, 0.26);
    thumbs = oldA.z > 0.0 ? oldA : homeA;
    tap = oldB.xy;
    if (px.y == 0 && px.x < 2) {
        vec2 cl = vec2(0.0), cr = vec2(0.0); float wl = 0.0, wr = 0.0;
        for (int j = 0; j < 6; j++) for (int i = 0; i < 12; i++) {
            vec2 uv = (vec2(float(i), float(j)) + 0.5) / vec2(12.0, 6.0);
            float dd = length(texture(uTex, uv).rgb - texture(uPrevSrc, uv).rgb);
            if (uv.x < 0.5) { cl += uv * dd; wl += dd; } else { cr += uv * dd; wr += dd; }
        }
        vec2 tl = wl > 0.15 ? cl / wl : homeA.xy;
        vec2 trr = wr > 0.15 ? cr / wr : homeA.zw;
        vec4 nA = vec4(mix(thumbs.xy, tl, 0.2), mix(thumbs.zw, trr, 0.2));
        vec2 nB = mix(oldB.xy, vec2(smoothstep(0.1, 0.6, wl), smoothstep(0.1, 0.6, wr)), 0.3);
        histOut = px.x == 0 ? nA : vec4(nB, 0.0, 1.0);
    }
    thumbs.xy += 0.012 * vec2(sin(uTime * 1.7), cos(uTime * 2.3));
    thumbs.zw += 0.012 * vec2(cos(uTime * 1.9), sin(uTime * 2.1));

    setup();

    mat3 CM = eul(camYaw, camPd, camRoll);
    vec3 R = CM[0], Uv = CM[1], F = CM[2];
    camRight = R; camUp = Uv; camFwd = F;

    vec2 p = (vUV - 0.5) * vec2(uRes.x / uRes.y, 1.0);
    float fl = 0.5 / tan(radians(fov) * 0.5);
    vec3 rd = normalize(p.x * R + p.y * Uv + fl * F);
    vec3 ro = camPos;

    gT = 1e9; gID = -1; gEm = 0.0; gCol = vec3(0.0); gN = vec3(0.0, 1.0, 0.0); gAux = vec4(0.0);
    if (HOSP) traceHospital(ro, rd); else traceStreet(ro, rd);
    tracePhoneAndHands(ro, rd);

    vec3 col;
    if (gID < 0) {
        col = HOSP ? vec3(0.5) : skyCol(rd);
    } else {
        vec3 pos = ro + rd * gT;
        vec3 alb = gCol; float em = gEm;
        if (gID == 1) alb = groundCol(pos);
        else if (gID == 2) { alb = facade(pos, gN, gAux); em = gEm; }
        else if (gID == 4) { alb = roomCol(pos, gN); em = gEm; }
        else if (gID == 5) { col = ecg(pos); alb = col; em = 1.0; }
        if (gID == 3) {
            vec2 uv = gAux.xy;
            vec3 s = texture(uTex, uv).rgb;
            s = s * s;
            if (crack > 0.5) { vec3 cr = crackOverlay(uv); s = mix(s, vec3(0.9), cr.x * 0.8) * (1.0 - cr.y); }
            float edge = smoothstep(0.0, 0.02, min(min(uv.x, 1.0 - uv.x), min(uv.y, 1.0 - uv.y)));
            col = s * 1.15 * mix(0.5, 1.0, edge);
        } else if (gID == 5) {
            col = alb;
        } else {
            if (HOSP) {
                vec3 L = normalize(vec3(0.0, -1.0, 0.0));
                col = alb * (0.5 + 0.35 * max(dot(gN, -L), 0.0));
                col = mix(col, alb * 1.8, em);
            } else {
                col = lightIt(pos, gN, alb, em);
                float fog = 1.0 - exp(-gT * 0.011);
                col = mix(col, skyCol(vec3(rd.x, 0.0, rd.z)) * 0.8, fog);
            }
        }
    }

    // --- look
    col = col / (1.0 + col * 0.18);
    col = sqrt(max(col, 0.0));
    float vig = 1.0 - 0.45 * dot(p, p);
    col *= vig;
    if (HOSP) {
        // head bandage in the corner of the eye
        float band = smoothstep(0.0, 0.05, 0.12 - abs(p.y - 0.30 + 0.35 * p.x)) * smoothstep(0.0, 0.1, p.y - 0.15);
        col = mix(col, vec3(0.93, 0.92, 0.88), band * 0.9 * step(0.15, abs(p.x) + 0.0));
    }
    col = mix(col, vec3(1.0), clamp(flashW, 0.0, 1.0));
    float fadeEp = smoothstep(0.0, 0.5, U) * smoothstep(0.0, 0.6, episode - U);
    col *= (1.0 - fadeBlack) * fadeEp;
    fragColor = vec4(col, 1.0);
}

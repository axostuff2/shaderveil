// Color grade: exposure, contrast, saturation, warmth, optional filmic curve.
uniform float exposure;   // @param 1.0 0.5 2.0
uniform float contrast;   // @param 1.05 0.5 1.8
uniform float saturation; // @param 1.1 0.0 2.0
uniform float warmth;     // @param 0.0 -1.0 1.0
uniform float tonemap;    // @param 0.0 0.0 1.0

vec3 aces(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

void main() {
    vec3 c = texture(uTex, vUV).rgb * exposure;
    c = mix(c, aces(c), tonemap);
    c = (c - 0.5) * contrast + 0.5;
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, saturation);
    c.r += warmth * 0.04;
    c.b -= warmth * 0.04;
    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}

// Contrast-adaptive sharpen (CAS-style, 5 taps).
uniform float strength; // @param 0.6 0.0 1.0

void main() {
    vec2 t = uTexel;
    vec3 c = texture(uTex, vUV).rgb;
    vec3 a = texture(uTex, vUV + vec2(0.0, t.y)).rgb;
    vec3 b = texture(uTex, vUV - vec2(0.0, t.y)).rgb;
    vec3 d = texture(uTex, vUV + vec2(t.x, 0.0)).rgb;
    vec3 e = texture(uTex, vUV - vec2(t.x, 0.0)).rgb;

    vec3 mn = min(min(min(a, b), min(d, e)), c);
    vec3 mx = max(max(max(a, b), max(d, e)), c);
    vec3 amp = sqrt(clamp(min(mn, 1.0 - mx) / max(mx, vec3(1e-4)), 0.0, 1.0));
    float peak = -1.0 / mix(8.0, 5.0, clamp(strength, 0.0, 1.0));
    vec3 wt = amp * peak;
    vec3 outc = (c + (a + b + d + e) * wt) / (1.0 + 4.0 * wt);
    fragColor = vec4(clamp(outc, 0.0, 1.0), 1.0);
}

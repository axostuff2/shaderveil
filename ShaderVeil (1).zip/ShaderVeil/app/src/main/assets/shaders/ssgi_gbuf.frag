// Screen-space GI on the geometry buffer, with temporal accumulation (needs Scene context).
// 8 taps per pixel per frame; the noise is averaged over frames through uHist/histOut, so it stays cheap.
// Place it after your colour grade and before bloom/sharpen.
uniform float intensity; // @param 1.0 0.0 4.0
uniform float radius;    // @param 1.2 0.2 4.0
uniform float accum;     // @param 0.12 0.03 1.0

float lum(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    float z = geoZ(vUV);
    if (z >= 199.0 || screenLocked(vUV) > 0.5) {
        fragColor = vec4(c, 1.0);
        histOut = vec4(0.0, 0.0, 0.0, 2.0);
        return;
    }
    float asp = uRes.x / uRes.y;
    vec3 P = geoPos(vUV);
    vec3 n = geoNormal(vUV);
    float rs = min(radius * uGeo.x / z, 0.25);          // gather radius in screen heights
    float rot = ign(gl_FragCoord.xy + float(uFrame % 16) * 5.588238) * 6.2831853;

    vec3 gi = vec3(0.0);
    const int N = 8;
    for (int i = 0; i < N; i++) {
        float fi = (float(i) + 0.5) / float(N);
        float a = float(i) * 2.39996323 + rot;
        vec2 off = vec2(cos(a) / asp, sin(a)) * (fi * fi * rs + 0.004);
        vec2 uvs = vUV + off;
        if (any(lessThan(uvs, vec2(0.0))) || any(greaterThan(uvs, vec2(1.0)))) continue;
        if (geoZ(uvs) >= 199.0) continue;
        vec3 v = geoPos(uvs) - P;
        float d = length(v) + 1e-3;
        vec3 l = v / d;
        float cosR = max(dot(n, l), 0.0);
        float cosS = max(dot(geoNormal(uvs), -l), 0.0);
        float w = cosR * cosS / (1.0 + 4.0 * d * d / (radius * radius));
        vec3 s = texture(uTex, uvs).rgb;
        gi += s * (0.3 + lum(s)) * w;
    }
    gi *= 2.0 / float(N);

    // temporal accumulation along the estimated motion
    vec2 hUV = vUV - sceneMotion(vUV);
    vec4 h = texture(uHist, hUV);
    bool inside = all(greaterThan(hUV, vec2(0.0))) && all(lessThan(hUV, vec2(1.0)));
    bool ok = inside && abs(h.a - z) < 0.1 * z;
    float k = ok ? accum : 1.0;
    vec3 g = mix(h.rgb, gi, k);
    histOut = vec4(g, z);
    fragColor = vec4(c + g * intensity * (c + 0.15), 1.0);
}

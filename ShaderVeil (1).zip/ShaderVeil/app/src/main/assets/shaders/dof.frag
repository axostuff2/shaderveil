// Depth of field from the reconstructed depth. Screen-locked pixels stay sharp.
// focus is an inverse depth (1 = nearest). With autoFocus on, it follows the centre of the screen.
uniform float focus;     // @param 0.6 0.0 1.0
uniform float autoFocus; // @param 1.0 0.0 1.0
uniform float amount;    // @param 14.0 0.0 40.0
uniform float range;     // @param 0.35 0.05 1.0

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    float f = focus;
    if (autoFocus > 0.5) {
        f = 0.25 * (sceneDepth(vec2(0.5, 0.5)) + sceneDepth(vec2(0.5, 0.4))
                  + sceneDepth(vec2(0.45, 0.45)) + sceneDepth(vec2(0.55, 0.45)));
    }
    float coc = clamp(abs(sceneDepth(vUV) - f) / range, 0.0, 1.0);
    coc *= clamp(sceneConf(vUV) * 2.0, 0.0, 1.0) * (1.0 - screenLocked(vUV));
    float rad = coc * amount;

    vec3 acc = c;
    float tw = 1.0;
    const int N = 16;
    for (int i = 0; i < N; i++) {
        float fi = float(i) + 0.5;
        float r = sqrt(fi / float(N));
        float a = fi * 2.39996323;
        vec2 off = vec2(cos(a), sin(a)) * r * rad * uTexel;
        acc += texture(uTex, vUV + off).rgb;
        tw += 1.0;
    }
    fragColor = vec4(acc / tw, 1.0);
}

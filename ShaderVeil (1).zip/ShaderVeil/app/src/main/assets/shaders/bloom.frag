// Single-pass bloom: thresholded golden-spiral gather, rotated per pixel to hide the pattern.
uniform float threshold; // @param 0.75 0.3 1.0
uniform float intensity; // @param 0.35 0.0 1.5
uniform float radius;    // @param 10.0 2.0 30.0

float ign(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    float rot = ign(gl_FragCoord.xy) * 6.2831853;
    vec3 acc = vec3(0.0);
    float tw = 0.0;
    const int N = 24;
    for (int i = 0; i < N; i++) {
        float fi = float(i) + 0.5;
        float r = sqrt(fi / float(N));
        float a = fi * 2.39996323 + rot;
        vec2 off = vec2(cos(a), sin(a)) * r * radius * uTexel;
        vec3 s = texture(uTex, vUV + off).rgb;
        float l = dot(s, vec3(0.2126, 0.7152, 0.0722));
        float k = smoothstep(threshold, 1.0, l);
        float wgt = 1.0 - r * 0.6;
        acc += s * k * wgt;
        tw += wgt;
    }
    acc /= tw;
    fragColor = vec4(c + acc * intensity, 1.0);
}

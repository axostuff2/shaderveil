// Ground-only SSR with tracked plane geometry ("match-move" style).
//
// 1. TRACK: the floor is a plane at camera-height 1 below the eye. Horizon row + vertical FOV fix the
//    camera pitch, so every pixel below the horizon has an exact 3D floor position.
// 2. ASSIGN: each pixel is classified as FLOOR or OBJECT. Objects are pixels whose motion-derived depth
//    (uCtx) is nearer than the floor would be at that row; screen-locked pixels (player/UI) count as
//    objects; everything above the horizon is sky. The floor plane is also what scales the depth: an
//    object's inverse depth maps to the floor row it stands on, which gives it metric position.
// 3. REFLECT: a floor pixel sees the mirror image of the world. Because the floor is a plane, the mirror
//    image of anything lies on the screen line through the pixel and the vertical vanishing point, so
//    the lookup is a 1D search along that line for the first point whose mirrored 3D position hits the
//    pixel's ray (exact for the tracked plane, no 3D ray marching in depth).
//
// Needs the scene helpers (Scene context). Keep `horizon` equal to the Scene-context horizon slider
// and `groundRef` equal to its "prior" slider, otherwise floor and objects get mixed up.
// debug: 0 off, 1 floor(green)/object(red) map, 2 hit position, 3 reflection only, 4 tracked floor grid
uniform float strength;  // @param 0.8 0.0 1.0
uniform float f0;        // @param 0.12 0.0 0.5
uniform float horizon;   // @param 0.55 0.2 0.9
uniform float fov;       // @param 70.0 40.0 110.0
uniform float groundRef; // @param 0.7 0.3 1.0
uniform float margin;    // @param 0.06 0.01 0.3
uniform float blur;      // @param 1.5 0.0 6.0
uniform float debug;     // @param 0.0 0.0 4.0

const int N = 40;

float gF; float gC; float gS; float gYh; float gAsp; float gRef; float gMargin; float gExt;

float ign(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

float gp(float y) {
    return gRef * clamp((gYh - y) / max(gYh, 0.05), 0.0, 1.0);
}

// world-space direction of the camera ray through uv (camera at origin, y up, floor at y = -1)
vec3 dirW(vec2 uv) {
    float sx = (uv.x - 0.5) * gAsp;
    float sy = uv.y - 0.5;
    return vec3(sx, sy * gC - gF * gS, sy * gS + gF * gC);
}

// x: 1 = object/sky, 0 = floor   y: inverse depth to use
vec2 classify(vec2 uv) {
    float d = sceneDepth(uv);
    if (uv.y >= gYh) return vec2(1.0, d);
    if (screenLocked(uv) > 0.5 || d - gp(uv.y) > gMargin) return vec2(1.0, d);
    // objects start above their base: look a little up to catch the lowest rows
    vec2 u2 = uv + vec2(0.0, gExt);
    if (u2.y < gYh) {
        float d2 = sceneDepth(u2);
        if (d2 - gp(u2.y) > gMargin && d > d2 - 0.5 * gMargin) return vec2(1.0, d2);
    }
    return vec2(0.0, gp(uv.y));
}

// <= 0 when the mirror image of the scene point under uv lies on or past the ray with elevation mp
float evalE(vec2 uv, float mp) {
    vec3 dw = dirW(uv);
    float dxz = length(dw.xz);
    float mb = dw.y / dxz;
    vec2 c = classify(uv);
    if (c.x < 0.5) return mb - mp;
    return -mb - 2.0 * gC * gYh * c.y / (gRef * dxz) - mp;
}

// screen position of the point on the vertical plane of azimuth a at ground parameter s = 1/distance
// (s < 0 continues above the horizon, up to the vanishing point of verticals)
vec2 uvAt(float s, vec2 a) {
    float den = gS * s + a.y * gC;
    vec2 q = vec2(a.x, -gC * s + a.y * gS) / den;
    return vec2(0.5 + gF * q.x / gAsp, 0.5 + gF * q.y);
}

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    int dbg = int(debug + 0.5);

    gAsp = uRes.x / uRes.y;
    gF = 0.5 / tan(radians(fov) * 0.5);
    float phi = atan((horizon - 0.5) / gF);
    gC = cos(phi); gS = sin(phi);
    gYh = horizon; gRef = groundRef; gMargin = margin;
    gExt = 1.5 * margin * gYh / max(gRef, 0.05);

    vec2 cls = classify(vUV);

    if (dbg == 1) {
        fragColor = vec4(mix(c, cls.x > 0.5 ? vec3(1.0, 0.1, 0.1) : vec3(0.1, 1.0, 0.2), 0.5), 1.0);
        return;
    }

    vec3 dw = dirW(vUV);
    float dxz = length(dw.xz);
    float mp = dw.y / dxz;
    float belowH = smoothstep(0.0, 0.04, gYh - vUV.y);
    bool isFloor = cls.x < 0.5 && mp < -0.002 && belowH > 0.0;

    if (dbg == 4) {
        if (isFloor) {
            float t = -1.0 / dw.y;
            vec2 g = t * dw.xz;
            vec2 w = abs(fract(g - 0.5) - 0.5) / max(fwidth(g), vec2(1e-4));
            float line = 1.0 - clamp(min(w.x, w.y), 0.0, 1.0);
            c = mix(c, vec3(1.0, 0.9, 0.2), line * 0.8 * exp(-t * 0.08));
        }
        float hl = 1.0 - clamp(abs(vUV.y - gYh) * uRes.y / 1.5, 0.0, 1.0);
        fragColor = vec4(mix(c, vec3(0.2, 0.8, 1.0), hl), 1.0);
        return;
    }

    if (!isFloor) {
        fragColor = vec4(c, 1.0);
        return;
    }

    // --- find the mirrored scene point along the line through the vertical vanishing point
    vec2 a = dw.xz / dxz;
    float sp = -mp;
    float Y = 0.5 / gF;
    float sTop = -a.y * (Y * gC - gS) / (gC + Y * gS);
    float jit = ign(gl_FragCoord.xy + float(uFrame % 8) * 5.588238);

    float eprev = 1.0;
    float tprev = 0.0;
    float tlo = 0.0;
    float thi = 0.0;
    bool hit = false;
    for (int i = 1; i <= N; i++) {
        float t = min((float(i) + jit) / float(N), 1.0);
        vec2 uv = uvAt(mix(sp, sTop, t), a);
        if (uv.x < 0.0 || uv.x > 1.0 || uv.y > 1.0) break;
        float e = evalE(uv, mp);
        if (e <= 0.0 && eprev > 0.0) {
            tlo = tprev; thi = t; hit = true;
            break;
        }
        eprev = e;
        tprev = t;
    }
    for (int k = 0; k < 5; k++) {
        if (!hit) break;
        float tm = 0.5 * (tlo + thi);
        vec2 uvm = uvAt(mix(sp, sTop, tm), a);
        if (evalE(uvm, mp) > 0.0) tlo = tm; else thi = tm;
    }

    vec2 hitUV = uvAt(mix(sp, sTop, thi), a);
    if (dbg == 2) {
        fragColor = vec4(hit ? vec3(hitUV, 1.0) : vec3(0.0), 1.0);
        return;
    }
    if (!hit) {
        fragColor = vec4(c, 1.0);
        return;
    }

    // --- shade
    vec2 dirPx = (hitUV - vUV) * uRes;
    float dl = length(dirPx);
    vec2 dn = dirPx / max(dl, 1e-3);
    float r = blur * clamp(dl / 150.0, 0.0, 3.0);
    vec2 st = dn * r * uTexel;
    vec3 refl = texture(uTex, hitUV).rgb * 0.4
              + texture(uTex, hitUV + st).rgb * 0.2
              + texture(uTex, hitUV - st).rgb * 0.2
              + texture(uTex, hitUV + 2.0 * st).rgb * 0.1
              + texture(uTex, hitUV - 2.0 * st).rgb * 0.1;

    vec3 dn3 = normalize(dw);
    float cosv = clamp(-dn3.y, 0.0, 1.0);
    float fres = f0 + (1.0 - f0) * pow(1.0 - cosv, 5.0);
    float edge = smoothstep(0.0, 0.06, min(min(hitUV.x, 1.0 - hitUV.x), 1.0 - hitUV.y));
    float amt = strength * clamp(fres * 3.0, 0.0, 1.0) * edge * belowH;

    if (dbg == 3) {
        fragColor = vec4(refl * edge * belowH, 1.0);
        return;
    }
    fragColor = vec4(mix(c, refl, clamp(amt, 0.0, 1.0)), 1.0);
}

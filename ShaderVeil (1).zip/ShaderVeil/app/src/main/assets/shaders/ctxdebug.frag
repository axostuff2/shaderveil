// Visualise the scene context. Put LAST in the chain while tuning the "Scene context" sliders.
// mode: 0 off, 1 depth (warm = near), 2 normals, 3 motion, 4 screen-locked mask, 5 confidence
uniform float mode; // @param 1.0 0.0 5.0

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    int m = int(mode + 0.5);
    vec3 o = c;
    if (m == 1) {
        float d = sceneDepth(vUV);
        o = vec3(d, d * 0.6, 1.0 - d);
    } else if (m == 2) {
        o = sceneNormal(vUV) * 0.5 + 0.5;
    } else if (m == 3) {
        vec2 v = sceneMotion(vUV) / uTexel;
        o = vec3(0.5 + v.x * 0.02, 0.5 + v.y * 0.02, 0.5);
    } else if (m == 4) {
        o = mix(c, vec3(1.0, 0.0, 0.4), screenLocked(vUV) * 0.85);
    } else if (m == 5) {
        o = vec3(sceneConf(vUV));
    }
    fragColor = vec4(o, 1.0);
}

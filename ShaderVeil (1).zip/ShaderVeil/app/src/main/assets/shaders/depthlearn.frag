// Progressive depth learner + final composite (needs ShaderVeil v0.3+ and the Scene context). Put it LAST.
//
// Three layers of memory, all kept in this shader's own history texture (uHist / histOut):
//  1. Per-pixel depth + confidence. Follows the camera motion, anchors to the motion depth while you move.
//  2. Edge-aware spreading: confident depth fills unsure pixels of similar colour, a few dozen frames to converge.
//  3. Learned appearance model: a 32x32 table in the bottom-left corner of the frame (those 32x32 pixels are
//     left unprocessed) that learns "pixels that look like THIS, at this height on screen, have THIS depth, with
//     THIS much variance". It is trained every frame by random sampling of the screen, so the longer you look
//     around, the more surfaces it recognises, including ones you see again later or only partly measured.
//     It is used only where it has seen a colour often enough and the depth was consistent (low variance).
// Physical rule applied last: nothing can be farther than the floor at its screen row.
//
// mode 0 = FINAL (haze + contact shadows, faded out where confidence is low so unsure areas stay untouched)
//      1 = refined depth, 2 = raw context depth, 3 = confidence, 4 = learned model (depth it would guess)
// Keep horizon / groundRef equal to the Scene-context horizon / prior sliders.
uniform float mode;      // @param 0.0 0.0 4.0
uniform float strength;  // @param 0.8 0.0 1.0
uniform float haze;      // @param 0.8 0.0 3.0
uniform float ao;        // @param 0.6 0.0 1.5
uniform float spread;    // @param 28.0 6.0 80.0
uniform float colorK;    // @param 14.0 2.0 40.0
uniform float anchor;    // @param 0.5 0.1 1.0
uniform float learn;     // @param 1.0 0.0 1.0
uniform float horizon;   // @param 0.55 0.2 0.9
uniform float groundRef; // @param 0.7 0.3 1.0

const int TW = 32;
const int NBIN = 864;   // 4 height buckets x 6 x 6 x 6 colour bins

float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

bool inTable(vec2 uv) {
    ivec2 p = ivec2(uv * uRes);
    return p.x < TW && p.y < TW;
}

int binOf(vec3 rgb, float y) {
    float Y = dot(rgb, vec3(0.299, 0.587, 0.114));
    float U = (rgb.b - Y) * 0.5649 + 0.5;
    float V = (rgb.r - Y) * 0.7132 + 0.5;
    int lq = int(clamp(Y * 6.0, 0.0, 5.99));
    int uq = int(clamp(U * 6.0, 0.0, 5.99));
    int vq = int(clamp(V * 6.0, 0.0, 5.99));
    int yq = int(clamp(y * 4.0, 0.0, 3.99));
    return ((yq * 6 + uq) * 6 + vq) * 6 + lq;
}

vec4 tableAt(int bin) { return texelFetch(uHist, ivec2(bin % TW, bin / TW), 0); }

float floorD(float y) { return groundRef * clamp((horizon - y) / max(horizon, 0.05), 0.0, 1.0); }

void main() {
    vec3 c0 = texture(uTex, vUV).rgb;
    ivec2 px = ivec2(gl_FragCoord.xy);

    // ---------------------------------------------------------------- layer 3 training (table pixels)
    if (px.x < TW && px.y < TW) {
        int idx = px.y * TW + px.x;
        vec4 T = texelFetch(uHist, px, 0);
        if (idx < NBIN) {
            float sw = 0.0, sm = 0.0, s2 = 0.0;
            for (int i = 0; i < 160; i++) {
                vec2 r = vec2(hash(vec2(float(idx), float(i)) + float(uFrame % 97) * 1.37),
                              hash(vec2(float(i) * 3.1 + 7.0, float(idx) + float(uFrame % 89) * 2.11)));
                if (inTable(r)) continue;
                if (binOf(texture(uTex, r).rgb, r.y) != idx) continue;
                vec4 hq = texture(uHist, r);
                sm += hq.g * hq.r;
                s2 += hq.g * hq.r * hq.r;
                sw += hq.g;
            }
            float W0 = T.b * 0.997;
            float W1 = W0 + sw;
            T = vec4((T.r * W0 + sm) / max(W1, 1e-4), (T.g * W0 + s2) / max(W1, 1e-4), min(W1, 300.0), 1.0);
        }
        histOut = T;
        fragColor = vec4(c0, 1.0);
        return;
    }

    float dObs = sceneDepth(vUV);
    float wObs = sceneConf(vUV);
    float lock = screenLocked(vUV);
    float wo = smoothstep(0.15, 0.6, wObs) * (1.0 - lock);

    // ---------------------------------------------------------------- layer 1: memory follows the motion
    vec2 hUV = vUV - sceneMotion(vUV);
    bool inside = all(greaterThan(hUV, vec2(0.0))) && all(lessThan(hUV, vec2(1.0))) && !inTable(hUV);
    vec4 h = inside ? texture(uHist, hUV) : vec4(0.0);
    float Ch = h.g;
    float Dh = (h.g < 0.002 && h.r < 0.002) ? dObs : h.r;

    // ---------------------------------------------------------------- layer 2: edge-aware spreading
    float rot = ign(gl_FragCoord.xy + float(uFrame % 16) * 5.588238) * 6.2831853;
    float sd = 0.0, sc = 0.0, sw = 0.0, swc = 0.0;
    const int N = 14;
    for (int i = 0; i < N; i++) {
        float fi = (float(i) + 0.5) / float(N);
        float a = float(i) * 2.39996323 + rot;
        vec2 uvq = vUV + vec2(cos(a), sin(a)) * (fi * fi * spread + 2.0) * uTexel;
        if (any(lessThan(uvq, vec2(0.0))) || any(greaterThan(uvq, vec2(1.0))) || inTable(uvq)) continue;
        vec4 hq = texture(uHist, uvq - sceneMotion(uvq));
        float wc = exp(-colorK * length(texture(uTex, uvq).rgb - c0)) * (1.0 - 0.5 * fi);
        float w = wc * hq.g;
        sd += w * hq.r;
        sc += w * hq.g;
        sw += w;
        swc += wc;
    }
    float Dp = sw > 1e-3 ? sd / sw : Dh;
    float Cp = sw > 1e-3 ? (sc / sw) * 0.96 : 0.0;
    float trust = smoothstep(0.08, 0.35, sw / (swc + 1e-4));
    float fill = 0.3 * (1.0 - clamp(Ch, 0.0, 1.0)) * trust;
    float D = mix(Dh, Dp, fill);
    D = mix(D, dObs, wo * anchor);
    float C = max(Ch * 0.998, wo);
    C = max(C, mix(Ch, Cp, fill));

    // ---------------------------------------------------------------- layer 3 use: learned appearance prior
    vec4 T = tableAt(binOf(c0, vUV.y));
    float tVar = max(T.g - T.r * T.r, 0.0);
    float tConf = smoothstep(4.0, 24.0, T.b) * (1.0 - smoothstep(0.004, 0.03, tVar));
    float tw = tConf * (1.0 - trust) * (1.0 - clamp(C, 0.0, 1.0)) * learn * (1.0 - lock);
    D = mix(D, T.r, tw * 0.25);
    C = max(C, tw * 0.35);

    // ---------------------------------------------------------------- physical rule: nothing is farther than the floor
    if (vUV.y < horizon) D = max(D, floorD(vUV.y));
    D = clamp(D, 0.0, 1.5);
    histOut = vec4(D, C, 0.0, 1.0);

    // ---------------------------------------------------------------- output
    vec3 outc;
    if (mode < 0.5) {
        float conf = smoothstep(0.1, 0.5, C) * (1.0 - lock);
        float z = 1.0 / (0.1 + 9.9 * D);
        // haze colour from the sky strip at the top of the frame
        vec3 sky = (texture(uTex, vec2(0.25, 0.96)).rgb + texture(uTex, vec2(0.5, 0.96)).rgb + texture(uTex, vec2(0.75, 0.96)).rgb) / 3.0;
        float fog = clamp(1.0 - exp(-haze * 0.1 * z), 0.0, 0.8) * smoothstep(0.02, 0.08, D);
        vec3 e = mix(c0, mix(sky, vec3(0.8), 0.25), fog);
        // contact shadows from neighbours that are nearer than this pixel
        float occ = 0.0;
        for (int i = 0; i < 8; i++) {
            float a = float(i) * 0.785398 + rot;
            float r = (6.0 + 4.0 * float(i % 3)) ;
            vec2 uvq = vUV + vec2(cos(a), sin(a)) * r * uTexel;
            if (any(lessThan(uvq, vec2(0.0))) || any(greaterThan(uvq, vec2(1.0))) || inTable(uvq)) continue;
            vec4 hq = texture(uHist, uvq);
            occ += clamp((hq.r - D - 0.03) * 10.0, 0.0, 1.0) * smoothstep(0.1, 0.5, hq.g);
        }
        e *= 1.0 - clamp(occ / 8.0 * ao, 0.0, 0.6);
        outc = mix(c0, e, conf * strength);
    } else if (mode < 1.5) {
        outc = vec3(D);
    } else if (mode < 2.5) {
        outc = vec3(dObs);
    } else if (mode < 3.5) {
        outc = vec3(clamp(C, 0.0, 1.0));
    } else {
        outc = vec3(tConf > 0.05 ? T.r : 0.0);
    }
    fragColor = vec4(outc, 1.0);
}

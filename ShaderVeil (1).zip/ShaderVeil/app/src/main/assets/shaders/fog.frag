// Distance fog / aerial perspective from the reconstructed depth.
uniform float density; // @param 0.6 0.0 1.5
uniform float power;   // @param 1.5 0.5 4.0
uniform float fogR;    // @param 0.62 0.0 1.0
uniform float fogG;    // @param 0.72 0.0 1.0
uniform float fogB;    // @param 0.85 0.0 1.0

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    float far = 1.0 - sceneDepth(vUV);
    float conf = smoothstep(0.0, 0.3, sceneConf(vUV));
    float amt = pow(far, power) * density * conf * (1.0 - screenLocked(vUV));
    c = mix(c, vec3(fogR, fogG, fogB), clamp(amt, 0.0, 1.0));
    fragColor = vec4(c, 1.0);
}

// Vignette + animated film grain.
uniform float vignette; // @param 0.35 0.0 1.0
uniform float grain;    // @param 0.03 0.0 0.2

float hash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    vec2 d = vUV - 0.5;
    float v = 1.0 - dot(d, d) * vignette * 2.0;
    c *= clamp(v, 0.0, 1.0);
    float n = hash(gl_FragCoord.xy + float(uFrame % 61) * 17.0) - 0.5;
    c += n * grain;
    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}

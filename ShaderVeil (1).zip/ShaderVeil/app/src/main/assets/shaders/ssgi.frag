// Approximate screen-space GI. There is NO depth buffer in a screen capture, so this treats
// luminance as the only signal: brighter neighbours act as emitters that bounce coloured light
// onto darker pixels (tinted by the receiving surface), plus a cheap local-contrast "AO" term.
uniform float intensity;  // @param 0.6 0.0 2.0
uniform float radius;     // @param 60.0 10.0 200.0
uniform float aoStrength; // @param 0.3 0.0 1.0

float lum(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

float ign(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    float lc = lum(c);
    float rot = ign(gl_FragCoord.xy + float(uFrame % 8) * 5.588238) * 6.2831853;

    vec3 gi = vec3(0.0);
    float avg = 0.0;
    const int N = 14;
    for (int i = 0; i < N; i++) {
        float fi = float(i) + 0.5;
        float r = fi / float(N);
        float a = fi * 2.39996323 + rot;
        vec2 off = vec2(cos(a), sin(a)) * r * r * radius * uTexel; // denser near the pixel
        vec3 s = texture(uTex, vUV + off).rgb;
        float ls = lum(s);
        avg += ls;
        gi += s * max(ls - lc, 0.0) * (1.0 - r);
    }
    avg /= float(N);
    gi /= float(N);

    float ao = clamp((avg - lc) * 2.0, 0.0, 1.0);
    vec3 outc = c * (1.0 - ao * aoStrength) + gi * intensity * (c + 0.35);
    fragColor = vec4(clamp(outc, 0.0, 1.0), 1.0);
}

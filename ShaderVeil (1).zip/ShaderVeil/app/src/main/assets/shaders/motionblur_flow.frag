// Motion blur from the shared optical-flow field (much cheaper than the standalone motionblur).
// Screen-locked pixels (UI, the player in third person) are left sharp.
uniform float shutter;  // @param 2.0 0.0 6.0
uniform float maxBlur;  // @param 24.0 4.0 64.0
uniform float lockKeep; // @param 1.0 0.0 1.0

void main() {
    vec2 v = sceneMotion(vUV) * shutter;
    v *= 1.0 - screenLocked(vUV) * lockKeep;
    float len = length(v / uTexel);
    if (len > maxBlur) v *= maxBlur / len;

    vec3 acc = vec3(0.0);
    const int N = 12;
    for (int i = 0; i < N; i++) {
        float t = float(i) / float(N - 1) - 0.5;
        acc += texture(uTex, vUV + v * t).rgb;
    }
    fragColor = vec4(acc / float(N), 1.0);
}

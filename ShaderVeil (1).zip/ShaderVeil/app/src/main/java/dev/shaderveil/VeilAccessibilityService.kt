package dev.shaderveil

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Does nothing except exist. Overlays added through an accessibility service
 * (TYPE_ACCESSIBILITY_OVERLAY) are "trusted", so Android 12+ lets touches pass through
 * them at any opacity. Normal app overlays must stay under 80% opacity or the system
 * blocks touches to the app underneath.
 */
class VeilAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: VeilAccessibilityService? = null
    }
}

package dev.shaderveil

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Minimal in-app GLSL editor. Save applies live if the overlay is running. */
class EditorActivity : Activity() {

    private lateinit var name: String
    private lateinit var edit: EditText
    private lateinit var log: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        name = intent.getStringExtra("name") ?: run { finish(); return }
        val f = ShaderLib.file(this, name)

        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((12 * dp).toInt(), (12 * dp).toInt(), (12 * dp).toInt(), (12 * dp).toInt())
        }
        root.addView(TextView(this).apply {
            text = "$name.frag"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
        })

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(s: String, click: () -> Unit) = Button(this).apply {
            text = s
            isAllCaps = false
            setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        bar.addView(btn("Save") { save() })
        bar.addView(btn("Check") { check() })
        bar.addView(btn("Delete") { confirmDelete() })
        root.addView(bar)

        edit = EditText(this).apply {
            setText(if (f.exists()) f.readText() else ShaderLib.TEMPLATE)
            typeface = Typeface.MONOSPACE
            textSize = 12f
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setHorizontallyScrolling(true)
            minLines = 14
        }
        root.addView(ScrollView(this).apply {
            addView(edit)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 3f)
        })

        log = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            val last = File(filesDir, "last_error.txt")
            text = if (last.exists() && last.length() > 0) "Last overlay errors:\n" + last.readText()
            else "Header provides: uTex, uOrig, uPrevSrc, uRes, uTexel, uTime, uFrame, vUV, fragColor.\n" +
                "Sliders: uniform float x; // @param default min max"
        }
        root.addView(ScrollView(this).apply {
            addView(log)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.5f)
        })
        setContentView(root)
    }

    private fun save() {
        ShaderLib.file(this, name).writeText(edit.text.toString())
        // Bump a pref so a running overlay recompiles its chain.
        ShaderLib.prefs(this).edit().putLong("reload", System.nanoTime()).apply()
        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        check()
    }

    private fun check() {
        log.text = try {
            ShaderLib.check(edit.text.toString())
        } catch (e: Exception) {
            "Check failed: ${e.message}"
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("Delete $name?")
            .setPositiveButton("Delete") { _, _ ->
                ShaderLib.file(this, name).delete()
                ShaderLib.saveChain(this, ShaderLib.chain(this).filter { it != name })
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

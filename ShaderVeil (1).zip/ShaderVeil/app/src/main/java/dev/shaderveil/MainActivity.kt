package dev.shaderveil

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val reqCapture = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ShaderLib.seed(this)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(2))
    }

    private fun button(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val prefs = ShaderLib.prefs(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }

        col.addView(text("ShaderVeil", 24f, true))
        col.addView(
            text(
                "1. Allow \"Display over other apps\".\n" +
                    "2. Open Roblox first, then come back here and press Start.\n" +
                    "3. In the system dialog choose \"A single app\" (Android 14+) and pick Roblox. " +
                    "\"Entire screen\" makes the overlay capture itself.",
                13f
            )
        )
        col.addView(button("1. Overlay permission") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        val accOn = VeilAccessibilityService.instance != null
        col.addView(
            text(
                if (accOn) "Touch pass-through: full (accessibility overlay active)"
                else "Touch pass-through: limited (overlay is 79% opaque so touches work). " +
                    "Enable the accessibility service below for full-strength effects.",
                13f
            )
        )
        col.addView(button("1b. Enable accessibility service (full strength)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("2. Start") { start() })
        col.addView(button("Stop") {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        })

        // render scale
        val scalePct = (prefs.getFloat("scale", 0.8f) * 100).toInt().coerceIn(30, 100)
        val scaleLabel = text("Render scale: $scalePct% (applies on next Start)", 13f)
        col.addView(scaleLabel)
        col.addView(SeekBar(this).apply {
            max = 70
            progress = scalePct - 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    scaleLabel.text = "Render scale: ${p + 30}% (applies on next Start)"
                    if (fromUser) prefs.edit().putFloat("scale", (p + 30) / 100f).apply()
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })

        col.addView(text("Scene context (for shaders that use sceneDepth etc.)", 16f, true))
        val ctxPct = (prefs.getFloat("ctxscale", 0.35f) * 100).toInt().coerceIn(15, 70)
        val ctxLabel = text("Context resolution: $ctxPct% (applies on next Start)", 13f)
        col.addView(ctxLabel)
        col.addView(SeekBar(this).apply {
            max = 55
            progress = ctxPct - 15
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    ctxLabel.text = "Context resolution: ${p + 15}% (applies on next Start)"
                    if (fromUser) prefs.edit().putFloat("ctxscale", (p + 15) / 100f).apply()
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })
        for (p in ShaderLib.CTX_PARAMS) col.addView(paramRow("ctx", p))

        col.addView(text("Shader chain (top runs first)", 16f, true))

        val names = ShaderLib.listNames(this)
        val chain = ShaderLib.chain(this).filter { it in names }
        val ordered = chain + names.filter { it !in chain }

        for (name in ordered) {
            val enabled = name in chain
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            row.addView(CheckBox(this).apply {
                text = name
                isChecked = enabled
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnCheckedChangeListener { _, on ->
                    val c = ShaderLib.chain(this@MainActivity).toMutableList()
                    c.remove(name)
                    if (on) c.add(name)
                    ShaderLib.saveChain(this@MainActivity, c)
                    buildUi()
                }
            })
            if (enabled) {
                row.addView(smallButton("^") { move(name, -1) })
                row.addView(smallButton("v") { move(name, +1) })
            }
            row.addView(smallButton("Edit") {
                startActivity(Intent(this, EditorActivity::class.java).putExtra("name", name))
            })
            col.addView(row)

            if (enabled) {
                val src = try {
                    ShaderLib.file(this, name).readText()
                } catch (_: Exception) {
                    ""
                }
                for (p in ShaderLib.parseParams(src)) col.addView(paramRow(name, p))
            }
        }

        col.addView(button("New shader") { newShader() })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun smallButton(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s
        isAllCaps = false
        minWidth = dp(48)
        minimumWidth = dp(48)
        setOnClickListener { onClick() }
    }

    private fun move(name: String, dir: Int) {
        val c = ShaderLib.chain(this).toMutableList()
        val i = c.indexOf(name)
        val j = i + dir
        if (i < 0 || j < 0 || j >= c.size) return
        c[i] = c[j].also { c[j] = c[i] }
        ShaderLib.saveChain(this, c)
        buildUi()
    }

    private fun paramRow(shader: String, p: ShaderLib.Param): View {
        val prefs = ShaderLib.prefs(this)
        val key = ShaderLib.paramKey(shader, p.name)
        val cur = prefs.getFloat(key, p.def)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), 0, 0, dp(4))
        }
        val label = TextView(this).apply {
            textSize = 12f
            text = "${p.name} = ${"%.3f".format(cur)}"
        }
        box.addView(label)
        box.addView(SeekBar(this).apply {
            max = 1000
            val span = (p.max - p.min).takeIf { it != 0f } ?: 1f
            progress = (((cur - p.min) / span) * 1000f).toInt().coerceIn(0, 1000)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, pr: Int, fromUser: Boolean) {
                    val v = p.min + span * pr / 1000f
                    label.text = "${p.name} = ${"%.3f".format(v)}"
                    if (fromUser) prefs.edit().putFloat(key, v).apply()
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })
        return box
    }

    private fun newShader() {
        val input = EditText(this).apply {
            hint = "name (letters, digits, _)"
            inputType = InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle("New shader")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val n = input.text.toString().trim().replace(Regex("[^A-Za-z0-9_]"), "_")
                if (n.isEmpty()) return@setPositiveButton
                val f = ShaderLib.file(this, n)
                if (!f.exists()) f.writeText(ShaderLib.TEMPLATE)
                startActivity(Intent(this, EditorActivity::class.java).putExtra("name", n))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun start() {
        if (VeilAccessibilityService.instance == null && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant the overlay permission first", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                startForegroundService(i)
                Toast.makeText(this, "Running - switch to your game", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Capture permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

# ShaderVeil

ReShade-style post-processing for Android games (built with Roblox mobile in mind).
It captures the screen with MediaProjection, runs the frames through a chain of GLSL ES 3.00
fragment shaders, and shows the result in a fullscreen, touch-transparent overlay.

## Build the APK (no PC needed)

1. Put `ShaderVeil.zip` in a GitHub repo (keep exactly ONE zip in the repo; re-uploading with the same name replaces it).
2. Make sure `.github/workflows/build.yml` exists (see the tutorial in chat).
3. Open the repo's **Actions** tab. A run starts on every commit; download the **ShaderVeil-debug-apk** artifact, unzip it, install `app-debug.apk`.
4. If the build fails, open the failed step and copy the error text.

## Use it

1. Open ShaderVeil. For full-strength effects enable the **accessibility service** (see below); otherwise allow "Display over other apps".
2. Open Roblox first. Come back, press **Start**.
3. In the system dialog choose **A single app** (Android 14+) and pick Roblox.
   - "Entire screen" makes the overlay capture itself, so effects compound (feedback). Avoid it.
4. Switch to Roblox. Toggle shaders, reorder them with the arrows, drag the sliders live.
5. Stop from the app or from the notification.

### Touch pass-through

Android 12+ blocks touches from reaching the app under a normal overlay that is more than 80% opaque.

- Without the accessibility service the overlay is 79% opaque (touches work, effects are about 80% strength).
- With the accessibility service enabled the overlay is trusted: full strength, touches pass through.
  If the toggle is greyed out: Settings, Apps, ShaderVeil, three-dot menu, **Allow restricted settings**.
  The service only draws the overlay; it does not read your screen.

## Scene context (v0.2)

A screen capture has color only, no depth buffer. ShaderVeil rebuilds a rough scene from motion:

1. **Optical flow** between consecutive frames (coarse-to-fine block matching on blurred luminance).
2. **Parallax depth**: motion relative to the top strip of the screen (usually sky/far) becomes relative
   inverse depth, normalised by how much motion there is, so it is speed independent.
3. **Memory**: each frame the previous depth is reprojected along the flow and blended in, so depth
   persists when you stop moving and refines as you move. Unseen areas start from a ground-plane guess.
4. **Edge-aware smoothing** guided by luminance edges fills in flat areas.
5. **Screen-locked mask**: pixels that stay put while everything else moves (UI, and the player in
   third person). Shaders can leave them alone.

The context only runs when an enabled shader uses the helpers below, so it costs nothing otherwise.
It is a hack, not true depth. Known weak spots:

- Depth only improves while the camera moves with some translation (walking). Pure turning gives no parallax.
- Other moving players or objects look "near".
- Flat, textureless surfaces have no motion information and get filled from neighbours.
- Needs a device with float render targets (nearly all). Otherwise context shaders pass through.

Tune it in the app under **Scene context**, and use the `ctxdebug` shader (put it last) to see
depth, normals, motion, the screen-locked mask and confidence while you adjust. Context resolution
(default 35% of the render size) trades accuracy for speed; lower it if the phone struggles.

### Helpers available in every shader

| function | returns |
|---|---|
| `sceneDepth(uv)` | relative inverse depth, 1 near, 0 far |
| `sceneZ(uv)` | pseudo distance, about 0.1 near to 10 far |
| `scenePos(uv)` | pseudo view-space position |
| `sceneNormal(uv)` | surface normal facing the camera (y up) |
| `sceneConf(uv)` | confidence 0..1 (use it to fade effects where depth is unknown) |
| `screenLocked(uv)` | 0..1 mask of screen-locked pixels |
| `sceneMotion(uv)` | motion since the last frame, in UV units |
| `sceneMotionConf(uv)` | confidence of that motion |

## Geometry buffer, history and performance (v0.3)

- **Geometry buffer** (`uGBuf`, built once per context update, only if a shader uses it): metric depth (in
  camera heights above the floor, scaled by the floor plane), view-space normals, floor mask. Helpers:
  `geoZ(uv)`, `geoNormal(uv)`, `geoFloor(uv)`, `geoPos(uv)` (view space: x right, y up, z toward camera).
  It replaces the per-pixel normal reconstruction that `sceneNormal` does in every shader.
- **History**: write `histOut = vec4(...)` and read `texture(uHist, uv)` to accumulate over frames
  (see `ssgi_gbuf`: 8 taps per frame, noise averaged over time). History is per shader, RGBA16F.
- **Quality governor** (Scene context sliders `autoq`, `budget`, `stride`): measures GPU time every 12 frames;
  over budget it first updates the context every 2nd frame, then lowers context resolution, and recovers
  when there is headroom. `stride` forces a fixed update interval, `autoq` 0 turns the governor off.
- Set the context `fov` and `margin` to match the game; the floor/horizon sliders define the tracked plane.

## Writing shaders

Edit in-app (**Edit**) or tap **New shader**. A shader file is just the body of a fragment shader:
`ShaderLib.HEADER` is prepended and provides

| name | meaning |
|---|---|
| `uTex` | output of the previous pass (raw frame for the first pass) |
| `uOrig` | raw captured frame |
| `uPrevSrc` | raw captured frame from the previous update |
| `uRes`, `uTexel` | texture size in pixels and 1/size |
| `uTime`, `uFrame` | seconds and frame counter |
| `vUV`, `fragColor` | input UV (0..1, origin bottom-left) and output colour |

Sliders: `uniform float amount; // @param default min max`

Save applies live. **Check** compiles it and shows the log; line numbers match your file.

## Built-in shaders

Classic (color only): `grade`, `sharpen`, `bloom`, `filmlook`, `motionblur`, `ssgi`, `ssr`.

Context-aware: `ao`, `dof`, `fog`, `ssgi_depth`, `ssgi_gbuf`, `ssr_depth`, `ssr_ground`, `motionblur_flow`, `ctxdebug`.

`ssr_ground` reflects only the floor, using a tracked ground plane (horizon + FOV sliders). Set its `horizon` and
`groundRef` equal to the Scene context horizon / prior sliders, and use `debug` 4 to overlay the tracked floor grid
and tune horizon/fov until the grid sticks to the floor. `debug` 1 shows what it treats as floor vs object.

Only grade + sharpen are enabled by default. When you update the app, new built-in shaders are added;
existing ones (and your edits) are never overwritten.

## Performance

Everything runs on the GPU at the **render scale** (default 80%). The overlay adds roughly one to two frames of latency.
Scene context adds a few small passes at context resolution. Lower the scales or disable heavy shaders
(`ssgi_depth`, `dof`) if the game stutters or the phone gets hot.

# ShaderVeil

ReShade-style post-processing for Android games (built with Roblox mobile in mind).
It captures the screen with MediaProjection, runs the frames through a chain of GLSL ES 3.00
fragment shaders, and shows the result in a fullscreen, touch-transparent overlay.

## Build the APK (no PC needed)

1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab, then **Build APK**, then **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download the **ShaderVeil-debug-apk** artifact, unzip it, install `app-debug.apk`.
4. If the build fails, open the failed step and copy the error text; it is almost always a one-line fix.

## Use it

1. Open ShaderVeil and press **Overlay permission**, allow "Display over other apps".
2. Open Roblox first. Come back, press **Start**.
3. In the system dialog choose **A single app** (Android 14+) and pick Roblox.
   - "Entire screen" makes the overlay capture itself, so effects compound (feedback). Avoid it.
   - Android 13 and older have no single-app option, so the feedback problem cannot be avoided there.
4. Switch to Roblox. Toggle shaders, reorder them with the arrows, drag the sliders live.
5. Stop from the app or from the notification.

The overlay hides itself when the captured app is not on screen, so it never blacks out your home screen.

## Writing shaders

Edit in-app (**Edit**) or tap **New shader**. A shader file is just the body of a fragment shader:
`ShaderLib.HEADER` is prepended and provides

| name | meaning |
|---|---|
| `uTex` | output of the previous pass (raw frame for the first pass) |
| `uOrig` | raw captured frame |
| `uPrevSrc` | raw captured frame from the previous update (for temporal effects) |
| `uRes`, `uTexel` | texture size in pixels and 1/size |
| `uTime`, `uFrame` | seconds and frame counter |
| `vUV`, `fragColor` | input UV (0..1, origin bottom-left) and output colour |

Sliders: `uniform float amount; // @param default min max`

Save applies live. **Check** compiles it and shows the log; line numbers match your file.

## Built-in shaders

`grade`, `sharpen`, `bloom`, `filmlook`, `motionblur`, `ssgi`, `ssr`. Only grade + sharpen are enabled by default.

Important limitation: a screen capture contains **color only, no depth buffer**. So:

- `motionblur` is real motion blur from optical flow between consecutive captured frames. Put it first in the chain.
- `ssr` assumes a horizontal ground plane below a `horizon` line and mirrors around object bases.
- `ssgi` treats luminance as the only signal (bright neighbours bounce light onto darker pixels).

Both `ssr` and `ssgi` are screen-space approximations, not true depth-based effects.

## Performance

Everything runs on the GPU at the **render scale** (default 80%). The overlay adds roughly one to two frames of latency.
Lower the scale or disable `motionblur` / `ssgi` if the game stutters or the phone gets hot.

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.shaderveil"
    compileSdk = 34

    defaultConfig {
        applicationId = "dev.shaderveil"
        minSdk = 26
        targetSdk = 34 // 34 is required for the Android 14 "share a single app" capture mode
        versionCode = 4
        versionName = "0.3"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

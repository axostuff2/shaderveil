package dev.shaderveil

import android.content.Context
import android.content.SharedPreferences
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns the GL thread. Pipeline per captured frame:
 *
 *   MediaProjection VirtualDisplay -> SurfaceTexture (external OES)
 *     -> copy into srcTex[cur]                       (raw frame, ping-ponged so we keep the previous one)
 *     -> user pass 0 -> passTex[0] -> user pass 1 -> passTex[1] -> ... -> last pass -> overlay surface
 *
 * Every user pass sees: uTex (previous pass), uOrig (raw frame), uPrevSrc (previous raw frame).
 */
class Renderer(
    private val app: Context,
    private val outSurface: Surface,
    private var w: Int,
    private var h: Int,
    private val onCaptureSurface: (Surface) -> Unit,
    private val onFirstFrame: () -> Unit
) : SurfaceTexture.OnFrameAvailableListener {

    private class Loc(val param: ShaderLib.Param, val loc: Int, val key: String)

    private class Pass(val name: String, val prog: Int, val params: List<Loc>) {
        val uTex = GLES30.glGetUniformLocation(prog, "uTex")
        val uOrig = GLES30.glGetUniformLocation(prog, "uOrig")
        val uPrev = GLES30.glGetUniformLocation(prog, "uPrevSrc")
        val uRes = GLES30.glGetUniformLocation(prog, "uRes")
        val uTexel = GLES30.glGetUniformLocation(prog, "uTexel")
        val uTime = GLES30.glGetUniformLocation(prog, "uTime")
        val uFrame = GLES30.glGetUniformLocation(prog, "uFrame")
    }

    private val thread = HandlerThread("veil-gl").also { it.start() }
    private val handler = Handler(thread.looper)

    @Volatile private var alive = true
    private val dirty = AtomicBoolean(true)
    private val values = ConcurrentHashMap<String, Float>()
    private val prefs: SharedPreferences = ShaderLib.prefs(app)

    // Must be a field: SharedPreferences only keeps a weak reference to listeners.
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { sp, key ->
        if (key == null) return@OnSharedPreferenceChangeListener
        if (key.startsWith("p_")) {
            values[key] = sp.getFloat(key, 0f)
        } else if (key == "chain" || key == "reload") {
            dirty.set(true)
        }
    }

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE

    private var oesTex = 0
    private var st: SurfaceTexture? = null
    private var capSurface: Surface? = null
    private var oesProg = 0
    private var uOesTex = 0
    private var uOesMat = 0
    private var blitProg = 0
    private var uBlitTex = 0
    private var vbo = 0

    private val srcTex = IntArray(2)
    private val srcFbo = IntArray(2)
    private val passTex = IntArray(2)
    private val passFbo = IntArray(2)
    private var cur = 0

    private var passes: List<Pass> = emptyList()
    private val stm = FloatArray(16)
    private var frame = 0
    private var startNs = System.nanoTime()
    private val sizeOut = IntArray(1)
    private var gotFirst = false

    init {
        for ((k, v) in prefs.all) if (k.startsWith("p_") && v is Float) values[k] = v
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        handler.post { initGl() }
    }

    // ------------------------------------------------------------------ setup

    private fun initGl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        EGL14.eglInitialize(eglDisplay, ver, 0, ver, 1)
        val attr = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, 0x40, // ES3
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(eglDisplay, attr, 0, cfgs, 0, 1, n, 0)
        eglContext = EGL14.eglCreateContext(
            eglDisplay, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
        )
        eglSurface = EGL14.eglCreateWindowSurface(
            eglDisplay, cfgs[0], outSurface, intArrayOf(EGL14.EGL_NONE), 0
        )
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
        EGL14.eglSwapInterval(eglDisplay, 0)

        // fullscreen quad
        val quad = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val bb = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder())
        bb.asFloatBuffer().put(quad)
        bb.position(0)
        val b = IntArray(1)
        GLES30.glGenBuffers(1, b, 0)
        vbo = b[0]
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, quad.size * 4, bb, GLES30.GL_STATIC_DRAW)

        // external texture the VirtualDisplay writes into
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        oesTex = t[0]
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val s = SurfaceTexture(oesTex)
        s.setDefaultBufferSize(w, h)
        s.setOnFrameAvailableListener(this, handler)
        st = s
        capSurface = Surface(s)

        // OES -> 2D copy program (applies the SurfaceTexture transform so the image is upright)
        val oesVs = """#version 300 es
layout(location = 0) in vec2 aPos;
uniform mat4 uST;
out vec2 vUV;
void main() {
    vec2 uv = aPos * 0.5 + 0.5;
    vUV = (uST * vec4(uv, 0.0, 1.0)).xy;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""
        val oesFs = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision mediump float;
uniform samplerExternalOES uTex;
in vec2 vUV;
out vec4 fragColor;
void main() { fragColor = texture(uTex, vUV); }
"""
        val (op, olog) = ShaderLib.link(oesVs, oesFs)
        if (op == 0) Log.e(TAG, "OES program failed: $olog")
        oesProg = op
        uOesTex = GLES30.glGetUniformLocation(op, "uTex")
        uOesMat = GLES30.glGetUniformLocation(op, "uST")

        val blitFs = """#version 300 es
precision mediump float;
uniform sampler2D uTex;
in vec2 vUV;
out vec4 fragColor;
void main() { fragColor = texture(uTex, vUV); }
"""
        val (bp, blog) = ShaderLib.link(ShaderLib.VERT, blitFs)
        if (bp == 0) Log.e(TAG, "blit program failed: $blog")
        blitProg = bp
        uBlitTex = GLES30.glGetUniformLocation(bp, "uTex")

        allocTargets()
        startNs = System.nanoTime()
        onCaptureSurface(capSurface!!)
    }

    private fun makeTarget(): Pair<Int, Int> {
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0])
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, w, h, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val f = IntArray(1)
        GLES30.glGenFramebuffers(1, f, 0)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, f[0])
        GLES30.glFramebufferTexture2D(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, t[0], 0
        )
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        return t[0] to f[0]
    }

    private fun allocTargets() {
        for (i in 0..1) {
            val a = makeTarget(); srcTex[i] = a.first; srcFbo[i] = a.second
            val b = makeTarget(); passTex[i] = b.first; passFbo[i] = b.second
        }
    }

    private fun freeTargets() {
        GLES30.glDeleteTextures(2, srcTex, 0)
        GLES30.glDeleteTextures(2, passTex, 0)
        GLES30.glDeleteFramebuffers(2, srcFbo, 0)
        GLES30.glDeleteFramebuffers(2, passFbo, 0)
    }

    private fun rebuildChain() {
        passes.forEach { GLES30.glDeleteProgram(it.prog) }
        val err = StringBuilder()
        val list = ArrayList<Pass>()
        for (name in ShaderLib.chain(app)) {
            val f = ShaderLib.file(app, name)
            if (!f.exists()) continue
            val src = f.readText()
            val (prog, log) = ShaderLib.compile(src)
            if (prog == 0) {
                err.append("[").append(name).append("]\n").append(log).append("\n")
                Log.e(TAG, "shader $name failed: $log")
                continue
            }
            val locs = ShaderLib.parseParams(src).map { p ->
                Loc(p, GLES30.glGetUniformLocation(prog, p.name), ShaderLib.paramKey(name, p.name))
            }
            list.add(Pass(name, prog, locs))
        }
        passes = list
        try {
            File(app.filesDir, "last_error.txt").writeText(err.toString())
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ frame loop

    override fun onFrameAvailable(s: SurfaceTexture?) {
        render()
    }

    private fun drawQuad() {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun copyOesTo(fbo: Int) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo)
        GLES30.glViewport(0, 0, w, h)
        GLES30.glUseProgram(oesProg)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES30.glUniform1i(uOesTex, 0)
        GLES30.glUniformMatrix4fv(uOesMat, 1, false, stm, 0)
        drawQuad()
    }

    private fun bindTex(unit: Int, tex: Int) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
    }

    private fun render() {
        if (!alive) return
        val s = st ?: return
        try {
            s.updateTexImage()
        } catch (e: Exception) {
            return
        }
        s.getTransformMatrix(stm)
        if (dirty.getAndSet(false)) rebuildChain()

        copyOesTo(srcFbo[cur])
        if (frame == 0) copyOesTo(srcFbo[1 - cur]) // seed "previous frame" so temporal shaders don't read garbage

        EGL14.eglQuerySurface(eglDisplay, eglSurface, EGL14.EGL_WIDTH, sizeOut, 0)
        val ow = sizeOut[0]
        EGL14.eglQuerySurface(eglDisplay, eglSurface, EGL14.EGL_HEIGHT, sizeOut, 0)
        val oh = sizeOut[0]

        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)

        val time = (System.nanoTime() - startNs) / 1e9f
        var input = srcTex[cur]
        val n = passes.size
        if (n == 0) {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            GLES30.glViewport(0, 0, ow, oh)
            GLES30.glUseProgram(blitProg)
            bindTex(0, input)
            GLES30.glUniform1i(uBlitTex, 0)
            drawQuad()
        } else {
            for (i in 0 until n) {
                val p = passes[i]
                val last = i == n - 1
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, if (last) 0 else passFbo[i and 1])
                if (last) GLES30.glViewport(0, 0, ow, oh) else GLES30.glViewport(0, 0, w, h)
                GLES30.glUseProgram(p.prog)
                bindTex(0, input)
                bindTex(1, srcTex[cur])
                bindTex(2, srcTex[1 - cur])
                GLES30.glUniform1i(p.uTex, 0)
                GLES30.glUniform1i(p.uOrig, 1)
                GLES30.glUniform1i(p.uPrev, 2)
                GLES30.glUniform2f(p.uRes, w.toFloat(), h.toFloat())
                GLES30.glUniform2f(p.uTexel, 1f / w, 1f / h)
                GLES30.glUniform1f(p.uTime, time)
                GLES30.glUniform1i(p.uFrame, frame)
                for (l in p.params) {
                    if (l.loc >= 0) GLES30.glUniform1f(l.loc, values[l.key] ?: l.param.def)
                }
                drawQuad()
                input = passTex[i and 1]
            }
        }
        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
        cur = 1 - cur
        frame++
        if (!gotFirst) {
            gotFirst = true
            onFirstFrame()
        }
    }

    // ------------------------------------------------------------------ control

    fun resize(nw: Int, nh: Int) {
        handler.post {
            if (!alive) return@post
            w = nw; h = nh
            st?.setDefaultBufferSize(w, h)
            freeTargets()
            allocTargets()
            frame = 0
        }
    }

    fun stop() {
        alive = false
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        handler.post {
            try {
                st?.setOnFrameAvailableListener(null)
                passes.forEach { GLES30.glDeleteProgram(it.prog) }
                passes = emptyList()
                freeTargets()
                GLES30.glDeleteProgram(oesProg)
                GLES30.glDeleteProgram(blitProg)
                capSurface?.release()
                st?.release()
                EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                EGL14.eglDestroySurface(eglDisplay, eglSurface)
                EGL14.eglDestroyContext(eglDisplay, eglContext)
                EGL14.eglTerminate(eglDisplay)
            } catch (e: Exception) {
                Log.e(TAG, "stop failed", e)
            }
            thread.quitSafely()
        }
    }

    companion object {
        private const val TAG = "ShaderVeil"
    }
}

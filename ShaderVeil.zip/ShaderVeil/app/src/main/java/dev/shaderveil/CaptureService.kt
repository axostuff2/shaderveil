package dev.shaderveil

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import android.graphics.PixelFormat

/**
 * Foreground service: MediaProjection capture -> GL renderer -> fullscreen, touch-transparent overlay.
 *
 * Feedback-loop note: on Android 14+ pick "A single app" in the system dialog. Then the capture
 * contains only that app's window, never this overlay. With "Entire screen" the overlay captures itself.
 */
class CaptureService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var renderer: Renderer? = null
    private var overlay: SurfaceView? = null
    private var lp: WindowManager.LayoutParams? = null

    private var contentVisible = true
    private var hasFrame = false
    private var running = false
    private var dpi = 320

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running || intent == null) return START_NOT_STICKY

        startForegroundCompat()

        val code = intent.getIntExtra("code", 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra("data", Intent::class.java)
        else
            @Suppress("DEPRECATION") intent.getParcelableExtra("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = try {
            mpm.getMediaProjection(code, data)
        } catch (e: Exception) {
            Log.e(TAG, "getMediaProjection failed", e)
            null
        }
        if (proj == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        projection = proj
        running = true

        // Android 14+: a callback must be registered before createVirtualDisplay.
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }

            override fun onCapturedContentVisibilityChanged(isVisible: Boolean) {
                // Single-app capture: hide the overlay whenever the captured app is not on screen,
                // otherwise a black frame would cover the home screen.
                contentVisible = isVisible
                main.post { applyVisibility() }
            }

            override fun onCapturedContentResize(width: Int, height: Int) {
                Log.i(TAG, "captured content resized to ${width}x${height}")
            }
        }, main)

        dpi = resources.displayMetrics.densityDpi
        buildOverlay()
        return START_NOT_STICKY
    }

    private fun procSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        val scale = ShaderLib.prefs(this).getFloat("scale", 0.8f).coerceIn(0.3f, 1f)
        val pw = ((dm.widthPixels * scale).toInt() and 1.inv()).coerceAtLeast(64)
        val ph = ((dm.heightPixels * scale).toInt() and 1.inv()).coerceAtLeast(64)
        return pw to ph
    }

    private fun buildOverlay() {
        val sv = SurfaceView(this)
        overlay = sv
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.OPAQUE
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.alpha = 0f // invisible until the first processed frame arrives
        if (Build.VERSION.SDK_INT >= 30) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        lp = params

        sv.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                startRenderer(holder.surface)
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                stopRenderer()
            }
        })
        wm.addView(sv, params)
    }

    private fun startRenderer(outSurface: Surface) {
        if (renderer != null) return
        val (pw, ph) = procSize()
        renderer = Renderer(
            applicationContext, outSurface, pw, ph,
            onCaptureSurface = { capture ->
                main.post {
                    val p = projection ?: return@post
                    if (vd != null) return@post
                    vd = p.createVirtualDisplay(
                        "ShaderVeil", pw, ph, dpi,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                        capture, null, null
                    )
                }
            },
            onFirstFrame = {
                main.post {
                    hasFrame = true
                    applyVisibility()
                }
            }
        )
    }

    private fun stopRenderer() {
        vd?.release()
        vd = null
        renderer?.stop()
        renderer = null
        hasFrame = false
    }

    private fun applyVisibility() {
        val v = overlay ?: return
        val p = lp ?: return
        val target = if (contentVisible && hasFrame) 1f else 0f
        if (p.alpha != target) {
            p.alpha = target
            try {
                wm.updateViewLayout(v, p)
            } catch (_: Exception) {
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!running) return
        val (pw, ph) = procSize()
        renderer?.resize(pw, ph)
        vd?.resize(pw, ph, dpi)
    }

    override fun onDestroy() {
        running = false
        stopRenderer()
        try {
            overlay?.let { wm.removeView(it) }
        } catch (_: Exception) {
        }
        overlay = null
        try {
            projection?.stop()
        } catch (_: Exception) {
        }
        projection = null
        super.onDestroy()
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "ShaderVeil", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("ShaderVeil is running")
            .setContentText("Tap to edit shaders")
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_delete), "Stop", stop
                ).build()
            )
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    companion object {
        const val ACTION_STOP = "dev.shaderveil.STOP"
        private const val CHANNEL = "veil"
        private const val NOTIF_ID = 7
        private const val TAG = "ShaderVeil"
    }
}

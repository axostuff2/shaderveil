package dev.shaderveil

import android.content.Context
import android.content.SharedPreferences
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES30
import java.io.File

/**
 * Shader storage, parameter parsing and GLSL compilation.
 *
 * A shader file is the *body* of a GLSL ES 3.00 fragment shader. HEADER is prepended, so
 * you only write uniforms and main(). Line numbers in compile errors match your file.
 *
 * Parameters:  uniform float name; // @param default min max
 */
object ShaderLib {

    const val VERT = """#version 300 es
layout(location = 0) in vec2 aPos;
out vec2 vUV;
void main() {
    vUV = aPos * 0.5 + 0.5;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

    const val HEADER = """#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
uniform sampler2D uTex;      // output of the previous pass (or the raw frame for the first pass)
uniform sampler2D uOrig;     // raw captured frame
uniform sampler2D uPrevSrc;  // raw captured frame from the previous update
uniform vec2 uRes;           // texture size in pixels
uniform vec2 uTexel;         // 1.0 / uRes
uniform float uTime;         // seconds
uniform int uFrame;          // frame counter
uniform sampler2D uCtx;      // scene context: r inverse depth (1 near, 0 far), g confidence, a screen-locked mask
uniform sampler2D uFlow;     // premultiplied motion field (use sceneMotion())
uniform vec2 uCtxTexel;      // texel size of the context textures
uniform float uFlowLod;      // top mip level of uFlow (global statistics)
in vec2 vUV;
out vec4 fragColor;

float sceneDepth(vec2 uv) { return texture(uCtx, uv).r; }
float sceneConf(vec2 uv) { return texture(uCtx, uv).g; }
float screenLocked(vec2 uv) { return texture(uCtx, uv).a; }
float sceneZ(vec2 uv) { return 1.0 / (0.1 + 9.9 * sceneDepth(uv)); }
vec3 scenePos(vec2 uv) {
    float z = sceneZ(uv);
    return vec3((uv - 0.5) * vec2(uRes.x / uRes.y, 1.0) * z, z);
}
vec3 sceneNormal(vec2 uv) {
    vec2 e = uCtxTexel * 1.5;
    vec3 px = scenePos(uv + vec2(e.x, 0.0)) - scenePos(uv - vec2(e.x, 0.0));
    vec3 py = scenePos(uv + vec2(0.0, e.y)) - scenePos(uv - vec2(0.0, e.y));
    return normalize(cross(py, px) + vec3(0.0, 0.0, -1e-5));
}
vec2 sceneGlobalMotion() {
    vec4 t = textureLod(uFlow, vec2(0.5), uFlowLod);
    return t.rg / max(t.a, 1e-3);
}
float sceneMotionConf(vec2 uv) { return textureLod(uFlow, uv, 0.0).a; }
vec2 sceneMotion(vec2 uv) {
    vec4 f = textureLod(uFlow, uv, 0.0);
    float c = clamp(f.a * 4.0, 0.0, 1.0);
    return mix(sceneGlobalMotion(), f.rg / max(f.a, 1e-3), c) * uCtxTexel;
}
#line 1
"""

    const val TEMPLATE = """// New shader.
// uTex = previous pass, uOrig = raw captured frame, uPrevSrc = previous raw frame.
// Declare sliders like:  uniform float amount; // @param default min max
uniform float amount; // @param 0.5 0.0 1.0

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    c = mix(c, 1.0 - c, amount);
    fragColor = vec4(c, 1.0);
}
"""

    data class Param(val name: String, val def: Float, val min: Float, val max: Float)

    private val PARAM = Regex("""uniform\s+float\s+(\w+)\s*;\s*//\s*@param\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)""")

    fun parseParams(src: String): List<Param> =
        PARAM.findAll(src).mapNotNull { m ->
            val d = m.groupValues[2].toFloatOrNull()
            val lo = m.groupValues[3].toFloatOrNull()
            val hi = m.groupValues[4].toFloatOrNull()
            if (d == null || lo == null || hi == null) null else Param(m.groupValues[1], d, lo, hi)
        }.toList()

    fun paramKey(shader: String, param: String) = "p_${shader}_$param"

    /** Tunables of the scene-context pipeline (stored like shader params under shader name "ctx"). */
    val CTX_PARAMS = listOf(
        Param("horizon", 0.55f, 0.2f, 0.9f),
        Param("prior", 0.7f, 0.0f, 1.0f),
        Param("rate", 0.5f, 0.05f, 1.0f),
        Param("gate", 0.4f, 0.1f, 2.0f),
        Param("blur", 6.0f, 1.0f, 16.0f),
        Param("edge", 12.0f, 2.0f, 40.0f),
        Param("search", 6.0f, 3.0f, 12.0f)
    )

    fun ctxDefault(name: String): Float = CTX_PARAMS.firstOrNull { it.name == name }?.def ?: 0f

    private val CTX_MARKERS = listOf(
        "sceneDepth", "sceneNormal", "scenePos", "sceneZ", "sceneConf", "screenLocked",
        "sceneMotion", "sceneGlobalMotion", "uCtx", "uFlow"
    )

    fun usesContext(src: String): Boolean = CTX_MARKERS.any { src.contains(it) }

    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("veil", Context.MODE_PRIVATE)

    fun dir(c: Context): File = File(c.filesDir, "shaders").also { it.mkdirs() }

    fun listNames(c: Context): List<String> =
        (dir(c).listFiles { f -> f.name.endsWith(".frag") } ?: emptyArray())
            .map { it.nameWithoutExtension }.sorted()

    fun file(c: Context, name: String) = File(dir(c), "$name.frag")

    private const val SEED_VERSION = 2

    /** Copy bundled shaders into app storage; on upgrades only add files that are missing. */
    fun seed(c: Context) {
        val d = dir(c)
        val p0 = prefs(c)
        val first = d.listFiles()?.any { it.name.endsWith(".frag") } != true
        if (first || p0.getInt("seedv", 0) < SEED_VERSION) {
            c.assets.list("shaders")?.forEach { n ->
                val out = File(d, n)
                if (!out.exists()) {
                    c.assets.open("shaders/$n").use { i ->
                        out.outputStream().use { o -> i.copyTo(o) }
                    }
                }
            }
            p0.edit().putInt("seedv", SEED_VERSION).apply()
        }
        val p = prefs(c)
        if (!p.contains("chain")) p.edit().putString("chain", "grade,sharpen").apply()
    }

    fun chain(c: Context): List<String> =
        prefs(c).getString("chain", "")!!.split(",").filter { it.isNotBlank() }

    fun saveChain(c: Context, list: List<String>) {
        prefs(c).edit().putString("chain", list.joinToString(",")).apply()
    }

    // ---------------------------------------------------------------- GL (needs a current context)

    private fun compileStage(type: Int, src: String): Pair<Int, String> {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val st = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, st, 0)
        if (st[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(s)
            GLES30.glDeleteShader(s)
            return 0 to log
        }
        return s to ""
    }

    fun link(vsSrc: String, fsSrc: String): Pair<Int, String> {
        val vs = compileStage(GLES30.GL_VERTEX_SHADER, vsSrc)
        if (vs.first == 0) return 0 to "vertex: ${vs.second}"
        val fs = compileStage(GLES30.GL_FRAGMENT_SHADER, fsSrc)
        if (fs.first == 0) {
            GLES30.glDeleteShader(vs.first)
            return 0 to fs.second
        }
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, vs.first)
        GLES30.glAttachShader(p, fs.first)
        GLES30.glLinkProgram(p)
        GLES30.glDeleteShader(vs.first)
        GLES30.glDeleteShader(fs.first)
        val st = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, st, 0)
        if (st[0] == 0) {
            val log = GLES30.glGetProgramInfoLog(p)
            GLES30.glDeleteProgram(p)
            return 0 to log
        }
        return p to ""
    }

    /** Compile a user shader body (HEADER is prepended). */
    fun compile(body: String): Pair<Int, String> = link(VERT, HEADER + body)

    /** Compile-check a shader in a throwaway offscreen context (used by the editor). */
    fun check(body: String): String {
        val d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        if (!EGL14.eglInitialize(d, v, 0, v, 1)) return "EGL init failed"
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        val attr = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, 0x40, // EGL_OPENGL_ES3_BIT_KHR
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_NONE
        )
        if (!EGL14.eglChooseConfig(d, attr, 0, cfgs, 0, 1, n, 0) || n[0] == 0) return "No EGL config"
        val ctx = EGL14.eglCreateContext(
            d, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
        )
        val surf = EGL14.eglCreatePbufferSurface(
            d, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
        )
        EGL14.eglMakeCurrent(d, surf, surf, ctx)
        val (p, log) = compile(body)
        if (p != 0) GLES30.glDeleteProgram(p)
        EGL14.eglMakeCurrent(d, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        EGL14.eglDestroySurface(d, surf)
        EGL14.eglDestroyContext(d, ctx)
        return if (p != 0) "OK - compiles." else log
    }
}

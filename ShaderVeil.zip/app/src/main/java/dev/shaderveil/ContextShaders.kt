package dev.shaderveil

/**
 * Scene-context passes. They run at reduced resolution (the "context resolution" slider) and only
 * when an enabled shader actually uses the scene helpers (sceneDepth, sceneNormal, ...).
 *
 *   LUMA   : source frame -> small luminance texture (R8). Two are kept (current + previous).
 *   FLOW   : block-matching optical flow between previous and current luminance.
 *            Output is PREMULTIPLIED by a match confidence w:
 *              r = w*fx, g = w*fy (ctx pixels), b = w*|f|^2, a = w
 *            so a mip chain gives confidence-weighted global mean / variance of motion for free.
 *   DEPTH  : parallax depth + persistent memory. Residual flow (flow minus global motion) is
 *            normalised by the frame's motion spread, giving relative inverse depth. The previous
 *            context is reprojected along the flow and blended in (a Kalman-style gain), seeded by a
 *            ground-plane prior. Also accumulates the "screen-locked" mask (pixels that stay put
 *            while everything else moves: UI, and the player in third person).
 *   SMOOTH : cross-bilateral smoothing guided by luminance edges. Its output is the context
 *            texture handed to user shaders AND the memory for the next frame.
 *
 * Context texture layout (uCtx):
 *   r = inverse depth (1 near, 0 far)   g = confidence   b = raw lock (memory)   a = dilated lock
 */
object ContextShaders {

    const val LUMA = """#version 300 es
precision highp float;
uniform sampler2D uTex;
uniform vec2 uTexel;
in vec2 vUV;
out vec4 fragColor;
void main() {
    vec2 o = uTexel * 1.5;
    vec3 c = texture(uTex, vUV + vec2(-o.x, -o.y)).rgb
           + texture(uTex, vUV + vec2( o.x, -o.y)).rgb
           + texture(uTex, vUV + vec2(-o.x,  o.y)).rgb
           + texture(uTex, vUV + vec2( o.x,  o.y)).rgb;
    c *= 0.25;
    fragColor = vec4(vec3(dot(c, vec3(0.299, 0.587, 0.114))), 1.0);
}
"""

    const val FLOW = """#version 300 es
precision highp float;
uniform sampler2D uC;
uniform sampler2D uP;
uniform vec2 uTexel;
uniform float uSearch;
in vec2 vUV;
out vec4 fragColor;

const vec2 OFF[5] = vec2[5](vec2(0.0), vec2(1.5, 0.0), vec2(-1.5, 0.0), vec2(0.0, 1.5), vec2(0.0, -1.5));
float cur[5];
float lodL;
float pscale;

float cost(vec2 d) {
    float s = 0.0;
    for (int i = 0; i < 5; i++) {
        s += abs(textureLod(uP, vUV + (d + OFF[i] * pscale) * uTexel, lodL).r - cur[i]);
    }
    return s;
}

void loadCur() {
    for (int i = 0; i < 5; i++) {
        cur[i] = textureLod(uC, vUV + OFF[i] * pscale * uTexel, lodL).r;
    }
}

void main() {
    // texture strength at full resolution (flat areas cannot be matched)
    float c0 = textureLod(uC, vUV, 0.0).r;
    float tex = 0.0;
    for (int i = 1; i < 5; i++) {
        tex += abs(textureLod(uC, vUV + OFF[i] * uTexel, 0.0).r - c0);
    }

    // coarse-to-fine search over a blurred luminance pyramid (lod 2 -> 1 -> 0 -> 0)
    vec2 best = vec2(0.0);
    float stepPx = uSearch;
    for (int lvl = 0; lvl < 4; lvl++) {
        lodL = (lvl == 0) ? 2.0 : ((lvl == 1) ? 1.0 : 0.0);
        pscale = exp2(lodL);
        loadCur();
        vec2 center = best;
        float bc = cost(center) + 0.0008 * length(center);
        for (int y = -1; y <= 1; y++) {
            for (int x = -1; x <= 1; x++) {
                if (x == 0 && y == 0) continue;
                vec2 d = center + vec2(float(x), float(y)) * stepPx;
                float k = cost(d) + 0.0008 * length(d);
                if (k < bc) {
                    bc = k;
                    best = d;
                }
            }
        }
        stepPx *= 0.4;
    }

    lodL = 0.0;
    pscale = 1.0;
    loadCur();
    float pc = cost(best) / 5.0;
    float texS = tex / 4.0;
    float w = (1.0 - smoothstep(0.03, 0.12, pc)) * smoothstep(0.008, 0.04, texS);
    vec2 f = -best;
    fragColor = vec4(w * f, w * dot(f, f), w);
}
"""

    const val DEPTH = """#version 300 es
precision highp float;
uniform sampler2D uFlow;
uniform sampler2D uMem;
uniform vec2 uTexel;
uniform float uTopLod;
uniform float uHorizon;
uniform float uPrior;
uniform float uRate;
uniform float uGate;
in vec2 vUV;
out vec4 fragColor;

void main() {
    vec4 F = textureLod(uFlow, vUV, 0.0);
    float w = F.a;
    vec2 f = F.rg / max(w, 1e-4);

    vec4 T = textureLod(uFlow, vec2(0.5), uTopLod);
    float tw = max(T.a, 1e-4);
    vec2 mf = T.rg / tw;
    float spread = sqrt(max(T.b / tw - dot(mf, mf), 0.0));
    float rel = smoothstep(0.02, 0.15, T.a);
    float camMove = length(mf);

    // Far reference: the top band of the screen is usually sky / distance, so its motion is ~pure
    // camera rotation. Measuring motion relative to it makes "more motion" always mean "nearer"
    // (subtracting the global mean would lose the sign). Falls back to the global mean if the band is flat.
    float bl = max(uTopLod - 4.0, 0.0);   // blocks ~1/8 of the frame tall: the top strip only
    float by = 0.94;
    vec4 Bt = textureLod(uFlow, vec2(0.2, by), bl)
            + textureLod(uFlow, vec2(0.5, by), bl)
            + textureLod(uFlow, vec2(0.8, by), bl);
    vec2 bf = Bt.rg / max(Bt.a, 1e-4);
    vec2 ref = mix(mf, bf, smoothstep(0.02, 0.12, Bt.a / 3.0));

    float gate = rel * smoothstep(uGate, uGate * 3.0, spread);
    float meas = clamp(length(f - ref) / (2.5 * max(spread, 0.25)), 0.0, 1.0);

    float prior = clamp((uHorizon - vUV.y) / max(uHorizon, 0.05), 0.0, 1.0);

    vec2 fm = (w > 0.25) ? f : mf;
    vec2 pUV = vUV - fm * uTexel;
    bool ok = all(greaterThan(pUV, vec2(0.0))) && all(lessThan(pUV, vec2(1.0)));
    vec4 m = ok ? texture(uMem, pUV) : vec4(0.0);

    float trust = smoothstep(0.0, 0.25, m.g);
    float d0 = mix(prior * uPrior, m.r, trust);
    float c0 = m.g * 0.995;

    float e = w * gate * uRate;
    float gain = e / (e + c0 + 0.02);
    float d = mix(d0, meas, gain);
    float c = clamp(c0 + e * 0.6, 0.0, 1.0);

    float lockEv = (w > 0.3 && length(f) < 0.3) ? 1.0 : 0.0;
    float moveGate = rel * smoothstep(1.0, 3.0, camMove + 2.0 * spread);
    float lock0 = texture(uMem, vUV).b;
    float lock = mix(lock0 * 0.999, lockEv, 0.08 * moveGate);

    fragColor = vec4(d, c, lock, 1.0);
}
"""

    const val SMOOTH = """#version 300 es
precision highp float;
uniform sampler2D uState;
uniform sampler2D uLuma;
uniform vec2 uTexel;
uniform float uRadius;
uniform float uEdge;
in vec2 vUV;
out vec4 fragColor;

void main() {
    vec4 s0 = texture(uState, vUV);
    float l0 = texture(uLuma, vUV).r;
    float sd = 0.0;
    float sw = 0.0;
    for (int i = 0; i < 12; i++) {
        float fi = float(i) + 0.5;
        float r = sqrt(fi / 12.0);
        float a = fi * 2.39996323;
        vec2 off = vec2(cos(a), sin(a)) * r * uRadius * uTexel;
        vec4 s = texture(uState, vUV + off);
        float l = texture(uLuma, vUV + off).r;
        float wgt = exp(-abs(l - l0) * uEdge) * (0.05 + s.g);
        sd += s.r * wgt;
        sw += wgt;
    }
    float d = (sw > 1e-4) ? sd / sw : s0.r;
    d = mix(d, s0.r, s0.g * 0.5);

    vec2 t = uTexel * 2.0;
    float nb = max(max(texture(uState, vUV + vec2(t.x, 0.0)).b, texture(uState, vUV - vec2(t.x, 0.0)).b),
                   max(texture(uState, vUV + vec2(0.0, t.y)).b, texture(uState, vUV - vec2(0.0, t.y)).b));
    float lk = max(s0.b, 0.8 * nb);
    fragColor = vec4(d, s0.g, s0.b, lk);
}
"""

    /**
     * GBUF: turns the context depth into a geometry buffer, once per context update, so user shaders
     * do not each recompute positions/normals per pixel. The floor plane (horizon + fov) gives metric scale:
     * an object's inverse depth maps to the floor row it stands on, hence to a distance in camera heights.
     *   rg = view-space normal xy   b = floor mask (1 floor)   a = metric depth z (camera heights, 200 = sky)
     */
    const val GBUF = """#version 300 es
precision highp float;
uniform sampler2D uCtx;
uniform vec2 uTexel;
uniform vec4 uGeo;      // f, cos(pitch), sin(pitch), horizon
uniform float uRef;     // ground inverse depth at the bottom row (= context "prior")
uniform float uMargin;
uniform float uAsp;
in vec2 vUV;
out vec4 fragColor;

float gp(float y) { return uRef * clamp((uGeo.w - y) / max(uGeo.w, 0.05), 0.0, 1.0); }

// x: 1 object, 0 floor; y: inverse depth to use
vec2 classify(vec2 uv) {
    vec4 c = texture(uCtx, uv);
    float d = c.r;
    if (uv.y >= uGeo.w) return vec2(1.0, d);
    if (c.a > 0.5 || d - gp(uv.y) > uMargin) return vec2(1.0, d);
    float ext = 1.5 * uMargin * uGeo.w / max(uRef, 0.05);
    vec2 u2 = uv + vec2(0.0, ext);
    if (u2.y < uGeo.w) {
        float d2 = texture(uCtx, u2).r;
        if (d2 - gp(u2.y) > uMargin && d > d2 - 0.5 * uMargin) return vec2(1.0, d2);
    }
    return vec2(0.0, gp(uv.y));
}

float zOf(vec2 uv, vec2 cls) {
    if (uv.y >= uGeo.w && cls.y < 0.01) return 200.0;
    float d = max(cls.y, 0.005);
    return min(uGeo.x * uRef / (uGeo.y * uGeo.w * d), 200.0);
}

vec3 pos(vec2 uv) {
    vec2 cls = classify(uv);
    float z = zOf(uv, cls);
    vec2 s = (uv - 0.5) * vec2(uAsp, 1.0);
    return vec3(s * (z / uGeo.x), -z);
}

void main() {
    vec2 cls = classify(vUV);
    float z = zOf(vUV, cls);
    vec3 n;
    if (cls.x < 0.5) {
        n = vec3(0.0, uGeo.y, uGeo.z);
    } else if (z >= 199.0) {
        n = vec3(0.0, 0.0, 1.0);
    } else {
        vec2 e = uTexel * 1.5;
        vec3 px = pos(vUV + vec2(e.x, 0.0)) - pos(vUV - vec2(e.x, 0.0));
        vec3 py = pos(vUV + vec2(0.0, e.y)) - pos(vUV - vec2(0.0, e.y));
        n = normalize(cross(px, py) + vec3(0.0, 0.0, 1e-6));
        if (n.z < 0.0) n = -n;
    }
    fragColor = vec4(n.xy, 1.0 - cls.x, z);
}
"""

    /** Injects the floor-aligned neural depth map into the context (screen-locked pixels are left alone). */
    const val FUSE = """#version 300 es
precision highp float;
uniform sampler2D uCtx;
uniform sampler2D uNeural;
uniform float uW;
in vec2 vUV;
out vec4 fragColor;
void main() {
    vec4 c = texture(uCtx, vUV);
    float n = texture(uNeural, vUV).r;
    float w = uW * (1.0 - c.a) * (0.6 + 0.4 * (1.0 - c.g));
    fragColor = vec4(mix(c.r, n, w), max(c.g, w * 0.9), c.b, c.a);
}
"""
}

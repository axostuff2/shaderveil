package dev.shaderveil

import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate

/**
 * Real neural monocular depth (MiDaS-small, TensorFlow Lite) running on a background thread, a few times a
 * second. The model only gives *relative* inverse depth, so every result is fitted to the tracked floor plane
 * (affine fit against the ground prior, robust to objects standing on it) before it is handed back. The
 * renderer fuses the aligned map into the scene context, where the motion-based depth memory carries it
 * forward between inferences.
 *
 * Everything here is best-effort: no model file, no TFLite, a failing GPU delegate... just means `ready`
 * stays false (or falls back to CPU) and the rest of the app runs as before.
 */
class NeuralDepth(private val ctx: Context) {

    @Volatile var ready = false; private set
    @Volatile var size = 256; private set
    @Volatile var status = "loading"; private set
    @Volatile var lastMs = 0f; private set

    private val busy = AtomicBoolean(false)
    private val result = AtomicReference<FloatArray?>(null)
    private val thread = HandlerThread("neural-depth").also { it.start() }
    private val handler = Handler(thread.looper)

    private var interp: Interpreter? = null
    private var gpu: GpuDelegate? = null
    private var nchw = false
    private var outCount = 0
    private var inBuf: ByteBuffer? = null
    private var outBuf: ByteBuffer? = null
    private var fa = 0f
    private var fb = 0f
    private var haveFit = false

    init { handler.post { load() } }

    val isBusy: Boolean get() = busy.get()

    private fun modelFile(): File? {
        val dst = File(ctx.filesDir, "models/midas_small.tflite")
        try {
            val names = ctx.assets.list("models") ?: emptyArray()
            if (!names.contains("midas_small.tflite")) return if (dst.exists()) dst else null
            val assetLen = ctx.assets.openFd("models/midas_small.tflite").use { it.length }
            if (!dst.exists() || dst.length() != assetLen) {
                dst.parentFile?.mkdirs()
                ctx.assets.open("models/midas_small.tflite").use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
            }
            return dst
        } catch (e: Exception) {
            Log.e(TAG, "model copy failed", e)
            return if (dst.exists()) dst else null
        }
    }

    private fun build(useGpu: Boolean, file: File): Interpreter {
        val mm = FileInputStream(file).use { it.channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length()) }
        val opts = Interpreter.Options()
        if (useGpu) {
            val d = GpuDelegate(CompatibilityList().bestOptionsForThisDevice)
            gpu = d
            opts.addDelegate(d)
        } else {
            opts.setNumThreads(4)
        }
        return Interpreter(mm, opts)
    }

    private fun load() {
        try {
            val f = modelFile()
            if (f == null) {
                status = "no model file (assets/models/midas_small.tflite)"
                Log.w(TAG, status)
                return
            }
            var ip: Interpreter? = null
            var how = "cpu"
            try {
                if (CompatibilityList().isDelegateSupportedOnThisDevice) {
                    ip = build(true, f)
                    how = "gpu"
                }
            } catch (t: Throwable) {
                Log.w(TAG, "gpu delegate failed, using cpu", t)
                try { gpu?.close() } catch (_: Throwable) {}
                gpu = null
                ip = null
            }
            val model: Interpreter = ip ?: build(false, f)
            interp = model
            val shape = model.getInputTensor(0).shape()
            nchw = shape.size == 4 && shape[1] == 3
            size = if (nchw) shape[2] else shape[1]
            inBuf = ByteBuffer.allocateDirect(size * size * 3 * 4).order(ByteOrder.nativeOrder())
            outCount = model.getOutputTensor(0).shape().fold(1) { a, b -> a * b }
            outBuf = ByteBuffer.allocateDirect(outCount * 4).order(ByteOrder.nativeOrder())
            status = "ok ($how, ${size}x$size)"
            ready = true
            Log.i(TAG, "neural depth ready: $status")
        } catch (t: Throwable) {
            status = "failed: ${t.message}"
            Log.e(TAG, "neural depth load failed", t)
        }
    }

    /** rgba: size*size*4 bytes in GL order (row 0 = bottom). Ignored while a previous frame is still running. */
    fun submit(rgba: ByteArray, horizon: Float, prior: Float) {
        if (!ready || !busy.compareAndSet(false, true)) return
        handler.post {
            try {
                run(rgba, horizon, prior)
            } catch (t: Throwable) {
                status = "run failed: ${t.message}"
                Log.e(TAG, "inference failed", t)
                if (gpu != null) { // fall back to CPU once
                    try { interp?.close(); gpu?.close() } catch (_: Throwable) {}
                    gpu = null
                    try {
                        interp = build(false, modelFile()!!)
                        status = "ok (cpu fallback)"
                    } catch (t2: Throwable) { ready = false }
                } else ready = false
            } finally {
                busy.set(false)
            }
        }
    }

    /** Latest aligned inverse-depth map (size*size floats, GL order, ~0 far .. 1 near), or null if nothing new. */
    fun take(): FloatArray? = result.getAndSet(null)

    private val MEAN = floatArrayOf(0.485f, 0.456f, 0.406f)
    private val STD = floatArrayOf(0.229f, 0.224f, 0.225f)

    private fun run(rgba: ByteArray, horizon: Float, prior: Float) {
        val n = size
        val ib = inBuf!!
        val ob = outBuf!!
        ib.rewind()
        val fl = ib.asFloatBuffer()
        if (!nchw) {
            for (y in 0 until n) {
                val sy = n - 1 - y // model wants the top row first
                for (x in 0 until n) {
                    val s = (sy * n + x) * 4
                    for (c in 0 until 3) fl.put(((rgba[s + c].toInt() and 255) / 255f - MEAN[c]) / STD[c])
                }
            }
        } else {
            for (c in 0 until 3) for (y in 0 until n) {
                val sy = n - 1 - y
                for (x in 0 until n) fl.put(((rgba[(sy * n + x) * 4 + c].toInt() and 255) / 255f - MEAN[c]) / STD[c])
            }
        }
        ib.rewind(); ob.rewind()
        val t0 = System.nanoTime()
        interp!!.run(ib, ob)
        lastMs = (System.nanoTime() - t0) / 1e6f
        ob.rewind()
        val m = FloatArray(outCount)
        ob.asFloatBuffer().get(m)

        // ---- align to the floor plane: d = a*m + b where the floor prior says d = prior*(horizon - v)/horizon
        val xs = ArrayList<Float>()
        val ys = ArrayList<Float>()
        var yy = 0
        while (yy < n) {
            val v = 1f - (yy + 0.5f) / n // GL-style height: 0 bottom
            if (v > 0.04f && v < horizon - 0.06f) {
                val target = prior * (horizon - v) / horizon
                var xx = 2
                while (xx < n) {
                    xs.add(m[yy * n + xx]); ys.add(target); xx += 4
                }
            }
            yy += 2
        }
        if (xs.size > 200) fit(xs, ys)
        if (haveFit) {
            val out = FloatArray(n * n)
            for (y in 0 until n) { // flip back to GL order
                val sy = n - 1 - y
                for (x in 0 until n) out[y * n + x] = (fa * m[sy * n + x] + fb).coerceIn(0f, 1f)
            }
            result.set(out)
        }
    }

    /** Huber-weighted least squares y = a x + b with a prior toward the previous fit (temporal stability). */
    private fun fit(xs: List<Float>, ys: List<Float>) {
        val cnt = xs.size
        val w = FloatArray(cnt) { 1f }
        var a = 0f
        var b = 0f
        var okFit = false
        for (iter in 0 until 8) {
            var sw = 0.0; var sx = 0.0; var sy = 0.0; var sxx = 0.0; var sxy = 0.0
            for (i in 0 until cnt) {
                val ww = w[i].toDouble(); val x = xs[i].toDouble(); val y = ys[i].toDouble()
                sw += ww; sx += ww * x; sy += ww * y; sxx += ww * x * x; sxy += ww * x * y
            }
            val den = sw * sxx - sx * sx
            if (sw < 1e-6 || den < 1e-9) return
            a = ((sw * sxy - sx * sy) / den).toFloat()
            b = ((sy - a * sx) / sw).toFloat()
            okFit = true
            // residuals -> weights (down-weight objects that stand on the floor / anything off the plane)
            val res = FloatArray(cnt) { Math.abs(a * xs[it] + b - ys[it]) }
            val sorted = res.copyOf().also { it.sort() }
            val s = (sorted[cnt / 2] * 1.4826f).coerceAtLeast(0.01f)
            for (i in 0 until cnt) w[i] = if (res[i] < 1.5f * s) 1f else (1.5f * s / res[i])
        }
        if (!okFit || a <= 0f) return // near must map to larger d; otherwise keep the previous fit
        if (!haveFit) { fa = a; fb = b; haveFit = true }
        else { fa += 0.35f * (a - fa); fb += 0.35f * (b - fb) }
    }

    fun close() {
        handler.post {
            try { interp?.close(); gpu?.close() } catch (_: Throwable) {}
            interp = null; gpu = null; ready = false
            thread.quitSafely()
        }
    }

    companion object { private const val TAG = "ShaderVeil.neural" }
}

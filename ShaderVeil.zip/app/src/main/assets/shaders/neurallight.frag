// "Neural relight": a DLSS-5-style post relight, done with hand-built maths instead of a trained network.
// Like DLSS 5 it takes only the FINISHED frame (plus motion) and changes lighting and material response,
// not geometry, textures or composition. Needs Scene context (geometry buffer). Slow on purpose: put it
// LAST-but-one (before sharpen), and give it `@scale 0.75` if your phone struggles.
//
// What it does, per pixel:
//   1. estimates the lighting already baked into the frame (edge-aware blur) vs the detail on top of it
//   2. builds a new lighting model from the geometry buffer: sun + sky ambient + floor bounce
//   3. adds contact shadows by marching toward the sun through the depth buffer, plus geometry AO
//   4. guesses materials from colour: skin -> soft subsurface wrap, foliage -> backlit translucency,
//      bright desaturated -> metal-ish glossy highlight, rest -> matte
//   5. applies the result as a gain on the frame (so textures stay yours), smoothed over time through
//      the per-pass history so it doesn't shimmer
// debug: 0 off, 1 shadow, 2 AO, 3 gain, 4 material masks (r skin, g foliage, b metal)
// @scale 1
uniform float amount;   // @param 0.85 0.0 1.0
uniform float sunAz;    // @param 40.0 -180.0 180.0
uniform float sunEl;    // @param 35.0 5.0 85.0
uniform float sunWarm;  // @param 0.6 0.0 1.0
uniform float shadowK;  // @param 0.75 0.0 1.0
uniform float aoK;      // @param 0.6 0.0 1.0
uniform float skinK;    // @param 0.8 0.0 1.0
uniform float leafK;    // @param 0.6 0.0 1.0
uniform float specK;    // @param 0.5 0.0 1.0
uniform float detail;   // @param 0.35 0.0 1.0
uniform float accum;    // @param 0.2 0.03 1.0
uniform float debug;    // @param 0.0 0.0 4.0

float lum(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }

float skinMask(vec3 c) {
    float mx = max(c.r, max(c.g, c.b));
    float mn = min(c.r, min(c.g, c.b));
    float s = (mx - mn) / (mx + 1e-3);
    float t = (c.g - c.b) / max(c.r - c.b, 1e-3);
    float ord = step(c.g, c.r + 0.01) * step(c.b, c.g + 0.01);
    return ord * smoothstep(0.12, 0.22, s) * (1.0 - smoothstep(0.55, 0.75, s))
         * smoothstep(0.2, 0.35, t) * (1.0 - smoothstep(0.7, 0.85, t)) * smoothstep(0.18, 0.35, mx);
}
float leafMask(vec3 c) {
    float mx = max(c.r, max(c.g, c.b));
    float s = (mx - min(c.r, min(c.g, c.b))) / (mx + 1e-3);
    return smoothstep(1.05, 1.25, c.g / max(max(c.r, c.b), 1e-3)) * smoothstep(0.2, 0.4, s);
}

// view space (z toward camera) -> uv
vec2 toUV(vec3 q) {
    float z = max(-q.z, 1e-3);
    return vec2(0.5 + uGeo.x * q.x / z / (uRes.x / uRes.y), 0.5 + uGeo.x * q.y / z);
}

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    float z = geoZ(vUV);
    if (z >= 199.0 || screenLocked(vUV) > 0.5) {
        fragColor = vec4(c, 1.0);
        histOut = vec4(1.0, 1.0, 1.0, 2.0);
        return;
    }
    int dbg = int(debug + 0.5);
    float asp = uRes.x / uRes.y;
    float jit = ign(gl_FragCoord.xy + float(uFrame % 16) * 5.588238);
    vec3 P = geoPos(vUV);
    vec3 N = geoNormal(vUV);
    vec3 V = vec3(0.0, 0.0, 1.0);

    // sun in view space (az 0 = from the camera side, 180 = behind the scene)
    float az = radians(sunAz), el = radians(sunEl);
    vec3 L = normalize(vec3(sin(az) * cos(el), sin(el), cos(az) * cos(el)));
    vec3 sunCol = mix(vec3(1.0), vec3(1.0, 0.82, 0.58), sunWarm) * 1.25;
    vec3 skyCol = vec3(0.5, 0.57, 0.68) * 0.5;

    // 1. baked lighting vs detail (edge-aware blur)
    float l0 = lum(c);
    float sw = 1.0, sl = l0;
    vec3 sc = c;
    for (int i = 0; i < 12; i++) {
        float a = float(i) * 2.39996323 + jit * 6.2831853;
        float rr = (i < 6 ? 0.012 : 0.04) * (0.6 + 0.4 * float(i % 6) / 5.0);
        vec2 u = vUV + vec2(cos(a) / asp, sin(a)) * rr;
        float zq = geoZ(u);
        float w = exp(-abs(zq - z) / (0.08 * z + 1e-3)) * exp(-abs(lum(texture(uTex, u).rgb) - l0) * 3.0);
        vec3 s = texture(uTex, u).rgb;
        sl += lum(s) * w; sc += s * w; sw += w;
    }
    float Lb = sl / sw;
    vec3 cb = sc / sw;

    // 2/3. shadows (march to the sun through the depth buffer) and AO
    float occl = 0.0;
    const int NS = 10;
    for (int i = 1; i <= NS; i++) {
        float t = 0.03 + 2.2 * pow((float(i) - 1.0 + jit) / float(NS), 1.7);
        vec3 Q = P + N * 0.02 + L * t;
        vec2 uq = toUV(Q);
        if (any(lessThan(uq, vec2(0.0))) || any(greaterThan(uq, vec2(1.0)))) break;
        float zs = geoZ(uq);
        float d = (-Q.z) - zs;                     // > 0: a surface sits in front of the ray point
        occl = max(occl, smoothstep(0.02, 0.12, d) * (1.0 - smoothstep(1.2, 2.2, d)));
    }
    float sh = 1.0 - occl;

    float ao = 0.0;
    float rs = min(0.7 * uGeo.x / z, 0.2);
    for (int i = 0; i < 8; i++) {
        float a = float(i) * 2.39996323 + jit * 6.2831853;
        vec2 u = vUV + vec2(cos(a) / asp, sin(a)) * ((float(i) + 0.5) / 8.0 * rs + 0.003);
        if (any(lessThan(u, vec2(0.0))) || any(greaterThan(u, vec2(1.0)))) continue;
        float zq = geoZ(u);
        if (zq >= 199.0) continue;
        vec3 v = geoPos(u) - P;
        float d = length(v) + 1e-3;
        ao += max(dot(N, v / d) - 0.12, 0.0) / (1.0 + 3.0 * d * d);
    }
    ao = clamp(1.0 - ao * 0.4, 0.0, 1.0);
    ao = mix(ao, 1.0, 0.25);

    // 4. material guesses
    float sk = skinMask(cb) * skinK;
    float lf = leafMask(cb) * leafK;
    float sat = (max(cb.r, max(cb.g, cb.b)) - min(cb.r, min(cb.g, cb.b))) / (max(cb.r, max(cb.g, cb.b)) + 1e-3);
    float mt = (1.0 - smoothstep(0.08, 0.3, sat)) * smoothstep(0.5, 0.85, Lb) * (1.0 - 0.7 * geoFloor(vUV));

    if (dbg == 1) { fragColor = vec4(vec3(sh), 1.0); histOut = vec4(1.0, 1.0, 1.0, z); return; }
    if (dbg == 2) { fragColor = vec4(vec3(ao), 1.0); histOut = vec4(1.0, 1.0, 1.0, z); return; }
    if (dbg == 4) { fragColor = vec4(sk, lf, mt, 1.0); histOut = vec4(1.0, 1.0, 1.0, z); return; }

    // lighting model
    float ndl = dot(N, L);
    float diff = max(ndl, 0.0);
    float wrap = clamp((ndl + 0.55) / 1.55, 0.0, 1.0);
    vec3 amb = mix(vec3(0.36, 0.32, 0.27), skyCol, N.y * 0.35 + 0.35) * mix(1.0, ao, aoK);
    float sunVis = mix(1.0, sh, shadowK);
    vec3 sun = sunCol * diff * sunVis;
    vec3 sss = sunCol * vec3(1.0, 0.5, 0.35) * (wrap - diff) * sunVis * 0.9 * sk;
    float back = pow(max(-L.z, 0.0), 1.5) * (0.4 + 0.6 * max(-ndl, 0.0));
    vec3 trans = vec3(0.55, 0.85, 0.25) * back * lf * 0.9;
    vec3 lit = amb + sun + sss + trans;
    vec3 ref = vec3(0.34, 0.33, 0.33) + sunCol * 0.32;       // what a "typical" baked frame already holds
    vec3 gain = lit / ref;

    // already-bright or already-dark pixels keep more of their original light
    gain = mix(vec3(1.0), gain, mix(1.0, 0.55, smoothstep(0.7, 1.0, Lb)));
    gain = clamp(gain, 0.25, 2.2);

    // temporal smoothing of the gain along motion
    vec2 hUV = vUV - sceneMotion(vUV);
    vec4 h = texture(uHist, hUV);
    bool inside = all(greaterThan(hUV, vec2(0.0))) && all(lessThan(hUV, vec2(1.0)));
    bool ok = inside && abs(h.a - z) < 0.1 * z;
    gain = mix(ok ? h.rgb : gain, gain, ok ? accum : 1.0);
    histOut = vec4(gain, z);

    if (dbg == 3) { fragColor = vec4(gain * 0.5, 1.0); return; }

    // 5. apply: gain on the frame, so textures stay the original
    vec3 out_ = c * mix(vec3(1.0), gain, amount);

    // clarity: push local contrast on the detail layer
    float dl = clamp(l0 / max(Lb, 0.02), 0.5, 2.0);
    out_ *= mix(1.0, dl, detail * 0.6 * amount);

    // glossy highlight (metal-ish and wet floor), shadowed and AO'd
    vec3 H = normalize(L + V);
    float ndh = max(dot(N, H), 0.0);
    float fres = 0.04 + 0.96 * pow(1.0 - max(dot(N, V), 0.0), 5.0);
    float gloss = mix(40.0, 140.0, mt);
    float sp = pow(ndh, gloss) * (0.25 + fres) * (0.15 + mt + 0.25 * geoFloor(vUV)) * sunVis * ao * step(0.0, ndl);
    out_ += sunCol * sp * specK * 1.4 * (0.25 + Lb) * amount;

    fragColor = vec4(out_, 1.0);
}

// Screen-space path tracer: real multi-bounce diffuse global illumination on the geometry buffer.
//
// Each pixel shoots cosine-weighted rays (2 per frame) from its surface point, marches them through the
// depth buffer, and when one hits something it reads that pixel's colour as the light arriving, then keeps
// bouncing (up to `bounces`) with the hit colour as albedo. Rays that escape see a sky gradient. Noise is
// averaged away over time through the per-pass history (reprojected along the motion field), so it gets
// cleaner the longer you hold still.
//
// Honest limits: it can only see what is on screen. Light from behind the camera or from hidden surfaces
// is missing, and with a neural/motion depth map the hit positions are approximate. Needs Scene context.
// Pair with neurallight (direct sun + shadows) and put this after it.
// debug: 0 off, 1 indirect light only, 2 hit rate (green = hit, blue = escaped sky)
// @scale 0.75
uniform float strength; // @param 1.0 0.0 4.0
uniform float range;    // @param 2.5 0.5 8.0
uniform float thick;    // @param 0.7 0.1 3.0
uniform float bounces;  // @param 2.0 1.0 3.0
uniform float skyI;     // @param 0.5 0.0 2.0
uniform float accum;    // @param 0.1 0.02 1.0
uniform float debug;    // @param 0.0 0.0 2.0

float lum(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }

vec2 toUV(vec3 q) {
    float z = max(-q.z, 1e-3);
    return vec2(0.5 + uGeo.x * q.x / z / (uRes.x / uRes.y), 0.5 + uGeo.x * q.y / z);
}

vec3 skyRad(vec3 d) {
    float t = clamp(d.y * 0.5 + 0.5, 0.0, 1.0);
    return mix(vec3(0.75, 0.8, 0.85), vec3(0.35, 0.55, 0.95), t) * skyI;
}

// 0 = escaped to the sky, 1 = hit (uvh/posh set), 2 = left the screen
int march(vec3 o, vec3 d, float jit, out vec2 uvh) {
    const int NS = 14;
    uvh = vec2(0.0);
    for (int i = 1; i <= NS; i++) {
        float t = 0.02 + range * pow((float(i) - 1.0 + jit) / float(NS), 1.6);
        vec3 Q = o + d * t;
        if (Q.z > -0.02) return 2;
        vec2 uq = toUV(Q);
        if (any(lessThan(uq, vec2(0.0))) || any(greaterThan(uq, vec2(1.0)))) return 2;
        float zs = geoZ(uq);
        if (zs >= 199.0) continue;
        float dd = (-Q.z) - zs;
        if (dd > 0.03 && dd < thick) { uvh = uq; return 1; }
    }
    return 0;
}

void main() {
    vec3 c = texture(uTex, vUV).rgb;
    float z = geoZ(vUV);
    if (z >= 199.0 || screenLocked(vUV) > 0.5) {
        fragColor = vec4(c, 1.0);
        histOut = vec4(0.0, 0.0, 0.0, 2.0);
        return;
    }
    vec3 P = geoPos(vUV);
    vec3 N = geoNormal(vUV);
    int B = int(bounces + 0.5);
    float fr = float(uFrame % 64);
    vec3 t0 = normalize(cross(abs(N.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0), N));
    vec3 b0 = cross(N, t0);

    vec3 E = vec3(0.0);
    float hits = 0.0, esc = 0.0;
    const int RAYS = 2;
    for (int r = 0; r < RAYS; r++) {
        vec3 o = P + N * 0.03;
        vec3 n = N, tg = t0, bt = b0;
        vec3 thr = vec3(1.0);
        for (int b = 0; b < 3; b++) {
            if (b >= B) break;
            float u1 = ign(gl_FragCoord.xy + vec2(fr * 5.588238 + float(r) * 31.7, float(b) * 17.3));
            float u2 = ign(gl_FragCoord.yx + vec2(fr * 3.17 + float(r) * 11.1, float(b) * 7.7) + 19.19);
            float rr = sqrt(u1), ph = 6.2831853 * u2;
            vec3 d = normalize(tg * (rr * cos(ph)) + bt * (rr * sin(ph)) + n * sqrt(max(1.0 - u1, 1e-4)));
            vec2 uvh;
            int res = march(o, d, ign(gl_FragCoord.xy + vec2(fr * 1.7 + float(b) * 3.1, float(r) * 5.3)), uvh);
            if (res == 0) { E += thr * skyRad(d); if (b == 0) esc += 1.0; break; }
            if (res == 2) { E += thr * skyRad(d) * 0.35; break; }
            vec3 hc = texture(uTex, uvh).rgb;
            E += thr * hc;
            if (b == 0) hits += 1.0;
            thr *= clamp(hc * 1.1, 0.0, 0.95);
            // continue the path from the hit point
            n = geoNormal(uvh);
            if (screenLocked(uvh) > 0.5) break;
            o = geoPos(uvh) + n * 0.03;
            tg = normalize(cross(abs(n.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0), n));
            bt = cross(n, tg);
        }
    }
    E /= float(RAYS);

    if (debug > 1.5) {
        fragColor = vec4(0.0, hits / float(RAYS), esc / float(RAYS), 1.0);
        histOut = vec4(E, z);
        return;
    }

    // temporal accumulation along the estimated motion
    vec2 hUV = vUV - sceneMotion(vUV);
    vec4 h = texture(uHist, hUV);
    bool inside = all(greaterThan(hUV, vec2(0.0))) && all(lessThan(hUV, vec2(1.0)));
    bool ok = inside && abs(h.a - z) < 0.1 * z;
    vec3 Ea = mix(ok ? h.rgb : E, E, ok ? accum : 1.0);
    histOut = vec4(Ea, z);

    if (debug > 0.5) { fragColor = vec4(Ea, 1.0); return; }
    fragColor = vec4(c + (c + 0.08) * Ea * strength * 0.8, 1.0);
}
